// Supabase Edge Function — verify Razorpay signature before an order is marked paid.
// Deploy: supabase functions deploy verify-payment
// Secrets: RAZORPAY_KEY_SECRET

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'

async function hmacSha256Hex(secret: string, message: string) {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  )
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message))
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, '0')).join('')
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type, authorization' } })
  }
  const secret = Deno.env.get('RAZORPAY_KEY_SECRET')
  if (!secret) return Response.json({ ok: false, error: 'missing secret' }, { status: 500 })
  const body = await req.json()
  const orderId = body.razorpay_order_id as string
  const paymentId = body.razorpay_payment_id as string
  const signature = body.razorpay_signature as string
  if (!orderId || !paymentId || !signature) {
    return Response.json({ ok: false, error: 'missing fields' }, { status: 400 })
  }
  const expected = await hmacSha256Hex(secret, `${orderId}|${paymentId}`)
  const ok = expected === signature
  return Response.json({ ok }, { headers: { 'Access-Control-Allow-Origin': '*' } })
})
