-- Lumen Folio — PostgreSQL schema for Supabase
-- Apply in the SQL editor. Enable RLS after load.

create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  email text unique,
  phone text,
  role text not null default 'customer' check (role in ('customer', 'owner')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  image_path text,
  featured boolean not null default false,
  hidden boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  long_description text,
  author text not null,
  author_bio text,
  category_id uuid references public.categories(id),
  tags text[] not null default '{}',
  isbn text,
  publisher text,
  language text default 'English',
  pages int,
  format text,
  dimensions text,
  published_at date,
  cost_price numeric(10,2) not null default 0,
  price numeric(10,2) not null,
  sale_price numeric(10,2),
  stock int not null default 0,
  reserved int not null default 0,
  low_stock_at int not null default 5,
  sku text unique,
  featured boolean not null default false,
  bestseller boolean not null default false,
  new_arrival boolean not null default false,
  published boolean not null default true,
  rating numeric(3,2) not null default 0,
  review_count int not null default 0,
  cover_tone text,
  views int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  path text not null,
  alt text,
  sort_order int not null default 0
);

create table if not exists public.addresses (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles(id) on delete cascade,
  label text,
  name text not null,
  phone text not null,
  line1 text not null,
  line2 text,
  city text not null,
  state text not null,
  pincode text not null,
  is_default boolean not null default false
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text unique not null,
  customer_id uuid references public.profiles(id),
  customer_name text not null,
  email text not null,
  phone text not null,
  address jsonb not null,
  subtotal numeric(10,2) not null,
  discount numeric(10,2) not null default 0,
  shipping numeric(10,2) not null default 0,
  total numeric(10,2) not null,
  coupon_code text,
  payment_method text not null check (payment_method in ('cod', 'razorpay')),
  payment_status text not null check (payment_status in ('pending', 'paid', 'failed', 'refunded')),
  payment_id text,
  status text not null,
  timeline jsonb not null default '[]',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  title text not null,
  author text,
  qty int not null,
  unit_price numeric(10,2) not null,
  line_total numeric(10,2) not null
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id),
  provider text not null default 'razorpay',
  provider_payment_id text,
  provider_order_id text,
  signature text,
  amount numeric(10,2) not null,
  status text not null,
  raw jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  type text not null,
  value numeric(10,2) not null default 0,
  min_order numeric(10,2) not null default 0,
  max_discount numeric(10,2),
  category_id uuid references public.categories(id),
  product_id uuid references public.products(id),
  starts_at date not null,
  expires_at date not null,
  usage_limit int not null default 0,
  per_user_limit int not null default 1,
  used_count int not null default 0,
  active boolean not null default true,
  description text
);

create table if not exists public.coupon_usage (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references public.coupons(id),
  profile_id uuid references public.profiles(id),
  order_id uuid references public.orders(id),
  used_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  profile_id uuid references public.profiles(id),
  customer_name text not null,
  rating int not null check (rating between 1 and 5),
  body text not null,
  verified boolean not null default false,
  status text not null default 'pending' check (status in ('pending', 'approved', 'hidden')),
  created_at timestamptz not null default now()
);

create table if not exists public.wishlists (
  profile_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (profile_id, product_id)
);

create table if not exists public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  delta int not null,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.analytics_events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  product_id uuid references public.products(id),
  query text,
  profile_id uuid references public.profiles(id),
  at timestamptz not null default now()
);

create table if not exists public.website_settings (
  id text primary key default 'live',
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.website_pages (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  content jsonb not null default '[]',
  seo jsonb,
  published boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.site_versions (
  id uuid primary key default gen_random_uuid(),
  payload jsonb not null,
  published_at timestamptz not null default now()
);

create table if not exists public.media (
  id uuid primary key default gen_random_uuid(),
  path text not null,
  alt text,
  created_at timestamptz not null default now()
);

create index if not exists products_category_idx on public.products(category_id);
create index if not exists products_slug_idx on public.products(slug);
create index if not exists orders_created_idx on public.orders(created_at);
create index if not exists analytics_name_idx on public.analytics_events(name, at);
create index if not exists events_query_idx on public.analytics_events(query);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.categories enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.reviews enable row level security;
alter table public.wishlists enable row level security;
alter table public.addresses enable row level security;
alter table public.coupons enable row level security;
alter table public.analytics_events enable row level security;
alter table public.website_settings enable row level security;
alter table public.payments enable row level security;

create or replace function public.is_owner()
returns boolean language sql stable as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'owner'
  );
$$;

create policy "public read published products" on public.products
  for select using (published = true or public.is_owner());

create policy "owner write products" on public.products
  for all using (public.is_owner()) with check (public.is_owner());

create policy "public read categories" on public.categories
  for select using (hidden = false or public.is_owner());

create policy "owner write categories" on public.categories
  for all using (public.is_owner()) with check (public.is_owner());

create policy "own profile" on public.profiles
  for select using (id = auth.uid() or public.is_owner());

create policy "update own profile" on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

create policy "own orders" on public.orders
  for select using (customer_id = auth.uid() or public.is_owner());

create policy "owner manage orders" on public.orders
  for update using (public.is_owner());

create policy "approved reviews public" on public.reviews
  for select using (status = 'approved' or public.is_owner() or profile_id = auth.uid());

create policy "own wishlist" on public.wishlists
  for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());

create policy "public coupons" on public.coupons
  for select using (active = true or public.is_owner());

create policy "live settings public" on public.website_settings
  for select using (true);

create policy "owner settings write" on public.website_settings
  for all using (public.is_owner()) with check (public.is_owner());

-- Create the owner user in Authentication, then:
-- update public.profiles set role = 'owner' where email = 'vvv@gmail.in';
