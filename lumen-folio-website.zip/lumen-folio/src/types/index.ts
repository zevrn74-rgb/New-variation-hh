export type BookFormat = 'Paperback' | 'Hardcover' | 'Board Book'

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'packed'
  | 'shipped'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled'
  | 'returned'
  | 'refunded'

export type PaymentMethod = 'cod' | 'upi' | 'razorpay'
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded'

export type CouponType =
  | 'percent'
  | 'fixed'
  | 'free_shipping'
  | 'category'
  | 'product'
  | 'bxgy'
  | 'b2g1'

export interface Category {
  id: string
  slug: string
  name: string
  description: string
  imageTone: string
  featured: boolean
  hidden: boolean
  sortOrder: number
}

export interface Book {
  id: string
  slug: string
  title: string
  author: string
  authorBio: string
  description: string
  longDescription: string
  categoryId: string
  tags: string[]
  isbn: string
  publisher: string
  language: string
  pages: number
  format: BookFormat
  dimensions: string
  publishedAt: string
  costPrice: number
  price: number
  salePrice: number | null
  stock: number
  reserved: number
  lowStockAt: number
  sku: string
  featured: boolean
  bestseller: boolean
  newArrival: boolean
  published: boolean
  rating: number
  reviewCount: number
  coverTone: string
  views: number
  wishlistCount: number
  cartAdds: number
  createdAt: string
  updatedAt: string
}

export interface Review {
  id: string
  bookId: string
  customerName: string
  customerId?: string
  rating: number
  body: string
  date: string
  verified: boolean
  status: 'pending' | 'approved' | 'hidden'
}

export interface Address {
  id: string
  label: string
  name: string
  phone: string
  line1: string
  line2?: string
  city: string
  state: string
  pincode: string
  isDefault?: boolean
}

export interface CartItem {
  bookId: string
  qty: number
  savedForLater?: boolean
}

export interface Coupon {
  id: string
  code: string
  type: CouponType
  value: number
  minOrder: number
  maxDiscount: number | null
  categoryId?: string
  productId?: string
  buyQty?: number
  getQty?: number
  startsAt: string
  expiresAt: string
  usageLimit: number
  perUserLimit: number
  usedCount: number
  active: boolean
  description: string
}

export interface OrderItem {
  bookId: string
  title: string
  author: string
  qty: number
  unitPrice: number
  lineTotal: number
}

export interface Order {
  id: string
  orderNumber: string
  customerId?: string
  customerName: string
  email: string
  phone: string
  address: Address
  items: OrderItem[]
  subtotal: number
  discount: number
  shipping: number
  total: number
  couponCode?: string
  paymentMethod: PaymentMethod
  paymentStatus: PaymentStatus
  paymentId?: string
  upiRef?: string
  status: OrderStatus
  timeline: { status: OrderStatus | 'placed'; at: string; note?: string }[]
  createdAt: string
  updatedAt: string
}

export interface Profile {
  id: string
  name: string
  email: string
  phone: string
  role: 'customer' | 'owner'
  addresses: Address[]
  createdAt: string
}

export interface SiteSettings {
  storeName: string
  tagline: string
  description: string
  phone: string
  email: string
  whatsapp: string
  address: string
  copyright: string
  logoText: string
  social: { instagram: string; twitter: string; youtube: string }
  colors: {
    ink: string
    paper: string
    cream: string
    clay: string
    forest: string
    gold: string
  }
  fonts: { heading: string; body: string }
  announcement: { enabled: boolean; text: string; link: string }
  seo: { title: string; description: string; ogImage: string }
  hero: {
    headline: string
    subheadline: string
    primaryCta: string
    primaryHref: string
    secondaryCta: string
    secondaryHref: string
    alignment: 'left' | 'center'
  }
  sectionVisibility: Record<string, boolean>
  footerText: string
  upiId: string
  upiName: string
}

export interface AnalyticsEvent {
  id: string
  name: 'view' | 'add_to_cart' | 'wishlist' | 'search' | 'checkout_start' | 'purchase'
  bookId?: string
  query?: string
  at: string
}
