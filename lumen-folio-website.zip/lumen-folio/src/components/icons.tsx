import type { SVGProps } from 'react'

type P = SVGProps<SVGSVGElement> & { size?: number }
function S({ size = 20, children, ...rest }: P & { children: React.ReactNode }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...rest}>
      {children}
    </svg>
  )
}

export const IconSearch = (p: P) => <S {...p}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></S>
export const IconHeart = (p: P) => <S {...p}><path d="M19.5 12.6 12 20l-7.5-7.4A4.5 4.5 0 1 1 12 6.2a4.5 4.5 0 1 1 7.5 6.4Z" /></S>
export const IconUser = (p: P) => <S {...p}><circle cx="12" cy="8" r="3.2" /><path d="M5 19a7 7 0 0 1 14 0" /></S>
export const IconBag = (p: P) => <S {...p}><path d="M6 8h12l-1 12H7L6 8Z" /><path d="M9 8V7a3 3 0 0 1 6 0v1" /></S>
export const IconHome = (p: P) => <S {...p}><path d="M4 11.5 12 4l8 7.5V20H4z" /></S>
export const IconShop = (p: P) => <S {...p}><rect x="4" y="7" width="16" height="13" /><path d="M8 7V5h8v2" /></S>
export const IconStar = (p: P) => <S {...p}><path d="m12 3 2.4 5.6L20 9.2l-4.4 3.8L16.8 19 12 16.2 7.2 19l1.2-6L4 9.2l5.6-.6Z" /></S>
export const IconClose = (p: P) => <S {...p}><path d="M6 6l12 12M18 6 6 18" /></S>
export const IconFilter = (p: P) => <S {...p}><path d="M4 6h16M7 12h10M10 18h4" /></S>
export const IconTruck = (p: P) => <S {...p}><rect x="2" y="7" width="13" height="9" /><path d="M15 10h4l3 4v2h-7" /><circle cx="7" cy="18" r="1.6" /><circle cx="18" cy="18" r="1.6" /></S>
export const IconShield = (p: P) => <S {...p}><path d="M12 3 5 6v6c0 4.2 2.8 7.4 7 9 4.2-1.6 7-4.8 7-9V6z" /></S>
export const IconBook = (p: P) => <S {...p}><path d="M5 5h10a3 3 0 0 1 3 3v11H8a3 3 0 0 0-3 3z" /><path d="M5 5v14" /></S>
export const IconPlus = (p: P) => <S {...p}><path d="M12 5v14M5 12h14" /></S>
export const IconMinus = (p: P) => <S {...p}><path d="M5 12h14" /></S>
