import type { ReactNode } from 'react'
import { useApp } from '../../store/AppState'
import { Link, useRouter } from '../../lib/router'
import { IconBag, IconHeart, IconHome, IconSearch, IconShop, IconUser } from '../icons'

export function StoreShell({ children }: { children: ReactNode }) {
  const { site, cart, wishlist, toasts } = useApp()
  const bagCount = cart.filter((i) => !i.savedForLater).reduce((s, i) => s + i.qty, 0)
  return (
    <div className="page-store">
      {site.sectionVisibility.announcement && site.announcement.enabled && (
        <div className="announce">
          <Link href={site.announcement.link}>{site.announcement.text}</Link>
        </div>
      )}
      <header className="header">
        <div className="container header-row">
          <Link href="/" className="logo">{site.logoText.split(' ')[0]} <em>{site.logoText.split(' ').slice(1).join(' ')}</em></Link>
          <nav className="nav-desk" aria-label="Primary">
            <Link href="/">Home</Link>
            <Link href="/shop">Shop</Link>
            <Link href="/categories">Categories</Link>
            <Link href="/new">New Arrivals</Link>
            <Link href="/bestsellers">Bestsellers</Link>
            <Link href="/deals">Deals</Link>
          </nav>
          <div className="header-actions">
            <Link href="/search" className="icon-btn" aria-label="Search"><IconSearch /></Link>
            <Link href="/wishlist" className="icon-btn" aria-label="Wishlist">
              <IconHeart />
              {wishlist.length > 0 && <span className="badge">{wishlist.length}</span>}
            </Link>
            <Link href="/account" className="icon-btn" aria-label="Account"><IconUser /></Link>
            <Link href="/cart" className="icon-btn" aria-label="Cart">
              <IconBag />
              {bagCount > 0 && <span className="badge">{bagCount}</span>}
            </Link>
          </div>
        </div>
      </header>
      <main>{children}</main>
      <footer className="footer">
        <div className="container footer-grid">
          <div>
            <div className="logo" style={{ color: 'var(--paper)', marginBottom: 12 }}>{site.storeName}</div>
            <p className="muted" style={{ color: 'rgba(244,239,230,0.75)' }}>{site.footerText}</p>
            <div className="space" />
            <p>{site.address}</p>
            <p>{site.phone} · {site.email}</p>
          </div>
          <div>
            <h4>Shop</h4>
            <Link href="/shop">All books</Link>
            <Link href="/new">New arrivals</Link>
            <Link href="/bestsellers">Bestsellers</Link>
            <Link href="/deals">Deals</Link>
            <Link href="/categories">Categories</Link>
          </div>
          <div>
            <h4>Help</h4>
            <Link href="/shipping">Shipping</Link>
            <Link href="/returns">Returns</Link>
            <Link href="/track-order">Track order</Link>
            <Link href="/faq">FAQ</Link>
            <Link href="/contact">Contact</Link>
          </div>
          <div>
            <h4>The shop</h4>
            <Link href="/about">About</Link>
            <Link href="/privacy">Privacy</Link>
            <Link href="/terms">Terms</Link>
            <a href={site.social.instagram}>Instagram</a>
            <a href={site.social.twitter}>X</a>
          </div>
        </div>
        <div className="container legal">
          <span>{site.copyright}</span>
          <span>GST invoices issued on every dispatch.</span>
        </div>
      </footer>
      <nav className="bottom-nav" aria-label="Mobile">
        <Link href="/"><IconHome size={18} /> Home</Link>
        <Link href="/shop"><IconShop size={18} /> Shop</Link>
        <Link href="/search"><IconSearch size={18} /> Search</Link>
        <Link href="/wishlist"><IconHeart size={18} /> Saved</Link>
        <Link href="/account"><IconUser size={18} /> Account</Link>
      </nav>
      <div className="toast-wrap" aria-live="polite">
        {toasts.map((t) => <div key={t.id} className="toast">{t.text}</div>)}
      </div>
    </div>
  )
}

export function PageHead({ kicker, title, children }: { kicker?: string; title: string; children?: ReactNode }) {
  return (
    <div className="container page-hero">
      {kicker && <div className="kicker">{kicker}</div>}
      <h1 style={{ fontSize: 'clamp(32px, 5vw, 52px)' }}>{title}</h1>
      {children}
    </div>
  )
}

export function useQuery() {
  return useRouter().query
}
