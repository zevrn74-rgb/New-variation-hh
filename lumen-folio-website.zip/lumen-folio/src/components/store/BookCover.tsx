import type { Book } from '../../types'

function luminance(hex: string) {
  const c = hex.replace('#', '')
  const n = parseInt(c.length === 3 ? c.split('').map((x) => x + x).join('') : c, 16)
  const r = (n >> 16) & 255
  const g = (n >> 8) & 255
  const b = n & 255
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

export function BookCover({ book, className = '' }: { book: Book; className?: string }) {
  const light = luminance(book.coverTone) > 160
  return (
    <div className={`cover ${light ? 'light' : ''} ${className}`} style={{ background: book.coverTone }}>
      <div className="mark">Lumen Folio</div>
      <div>
        <div className="ctitle">{book.title}</div>
        <div className="cauthor">{book.author}</div>
      </div>
    </div>
  )
}
