import type { Book } from '../../types'
import { discountPct, effectivePrice, formatMoney } from '../../lib/format'
import { Link } from '../../lib/router'
import { useApp } from '../../store/AppState'
import { BookCover } from './BookCover'
import { IconHeart } from '../icons'

export function Stars({ value }: { value: number }) {
  const full = Math.round(value)
  return <div className="stars" aria-label={`${value} out of 5`}>{Array.from({ length: 5 }, (_, i) => (i < full ? '★' : '☆')).join(' ')}</div>
}

export function BookCard({ book }: { book: Book }) {
  const { addToCart, toggleWishlist, wishlist } = useApp()
  const sale = effectivePrice(book.price, book.salePrice)
  const off = discountPct(book.price, book.salePrice)
  const available = book.stock - book.reserved
  return (
    <article className="book-card">
      <div style={{ position: 'relative' }}>
        <Link href={`/book/${book.slug}`}>
          <BookCover book={book} />
        </Link>
        <button className="wish-abs" aria-label="Wishlist" onClick={() => toggleWishlist(book.id)}>
          <IconHeart size={16} />
          {wishlist.includes(book.id) ? <span className="sr">Saved</span> : null}
        </button>
      </div>
      <div className="meta">
        <Link href={`/book/${book.slug}`} className="title">{book.title}</Link>
        <div className="author">{book.author}</div>
        <Stars value={book.rating} />
        <div className="price">
          <strong>{formatMoney(sale)}</strong>
          {off > 0 && <span className="was">{formatMoney(book.price)}</span>}
          {off > 0 && <span className="off">{off}% off</span>}
        </div>
        <div className="tiny">{available > 0 ? (available <= book.lowStockAt ? 'Low stock' : 'In stock') : 'Unavailable'}</div>
        <button className="btn ghost" style={{ padding: '8px 10px', minHeight: 38 }} disabled={available <= 0} onClick={() => addToCart(book.id)}>
          Add to bag
        </button>
      </div>
    </article>
  )
}

export function BookRail({ books }: { books: Book[] }) {
  return (
    <div className="book-grid">
      {books.map((b) => (
        <BookCard key={b.id} book={b} />
      ))}
    </div>
  )
}
