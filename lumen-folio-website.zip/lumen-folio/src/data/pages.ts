export const staticPages: Record<string, { title: string; kicker: string; body: string[] }> = {
  about: {
    title: 'A shop, not a warehouse.',
    kicker: 'About Lumen Folio',
    body: [
      'Lumen Folio started as a table of books we were tired of recommending from memory. We buy trade editions at wholesale, keep a tight list, and sell one copy at a time from Church Street in Bengaluru.',
      'The readers we buy for are not a demographic slide. They are students who need a first serious book on money, young managers who have outgrown slogans, parents who want language that respects a child, and fiction readers who still want character more than premise.',
      'We do not pretend to stock everything. We do promise that what is on the shelf has been handled by someone who will still answer the phone if the binding fails.',
    ],
  },
  contact: {
    title: 'Write, call, or walk in.',
    kicker: 'Contact',
    body: [
      'The shop is open Tuesday to Sunday, 11:00–20:00. Monday is receiving day; email still works.',
      'For order questions, include your order number. For school and bulk orders, write to schools@lumenfolio.in with a list and a date.',
    ],
  },
  shipping: {
    title: 'How a book leaves the shop.',
    kicker: 'Shipping',
    body: [
      'Orders placed before 14:00 IST on a working day are packed the same afternoon. We ship with Delhivery and Bluedart across India.',
      'Free standard shipping on prepaid orders above ₹799. Below that, shipping is ₹59. Cash on delivery adds ₹30 and is available on orders under ₹5,000.',
      'Metro cities usually see two to four working days. The rest of India, four to seven. Remote pin codes can take longer; we will write if a courier declines the lane.',
      'We do not ship editions overseas from this site yet. Write to us if you need a quote.',
    ],
  },
  returns: {
    title: 'If the book is wrong.',
    kicker: 'Returns & refunds',
    body: [
      'You have seven days from delivery to request a return on an unused book in saleable condition, with the invoice.',
      'Printing defects, missing pages, and courier damage are replaced or refunded as soon as we see a photograph. Do not wait out the seven days on a damaged copy.',
      'We do not take back books that have been marked, scented, or clearly read. Digital codes, if any, void the return.',
      'Refunds go back on the original method. Razorpay refunds typically post in five to seven working days. COD refunds are issued as a bank transfer after you send account details.',
    ],
  },
  faq: {
    title: 'Questions we answer every week.',
    kicker: 'FAQ',
    body: [],
  },
  privacy: {
    title: 'What we keep, and why.',
    kicker: 'Privacy policy',
    body: [
      'We collect the name, phone, email, and address required to fulfill an order. Payment card details are handled by Razorpay; we never store full card numbers.',
      'Accounts store order history and saved addresses so you do not type them twice. You may request deletion of an account by writing to privacy@lumenfolio.in. We retain invoices as required by Indian tax law.',
      'We do not sell customer lists. We send email only to people who asked for it, and every letter has a way out.',
      'Analytics events on this site are used to understand which titles are looked at and which searches fail. We do not build advertising profiles to sell to third parties.',
    ],
  },
  terms: {
    title: 'The agreement under the dust jacket.',
    kicker: 'Terms & conditions',
    body: [
      'By placing an order you offer to buy the listed title at the listed price, subject to stock. We may cancel an order if a title is discovered to be unavailable after you pay; you will be refunded in full.',
      'Prices include GST where applicable. Typographical errors may be corrected before dispatch.',
      'Content on this site — descriptions, photography of our covers, and editorial notes — is owned by Lumen Folio or used under licence. Book text remains the publisher’s copyright.',
      'Disputes are subject to the courts of Bengaluru, Karnataka.',
    ],
  },
}

export const faqs = [
  { q: 'Do you sell used books?', a: 'No. Everything on Lumen Folio is a new trade edition. If a binding is damaged in transit, we replace it.' },
  { q: 'Can I collect from the shop?', a: 'Yes. Choose Cash on Delivery or pay online, then write “collect from Church Street” in the order notes. We will hold the parcel for five days.' },
  { q: 'Do you wrap gifts?', a: 'We wrap in brown paper and twine at no charge if you ask at checkout. We do not print gift cards with handwriting yet — include a note and we will slip it in.' },
  { q: 'Are these the latest editions?', a: 'We stock the current trade paperback or hardcover unless the listing says otherwise. ISBNs are on every product page.' },
  { q: 'Can schools order in bulk?', a: 'Yes. Write to schools@lumenfolio.in with titles, quantities, and a delivery date. Trade terms apply above twenty copies.' },
  { q: 'Why is a title out of stock?', a: 'We would rather show zero than take money for a book that is on a boat. Use the notify control, or write to us and we will suggest a neighbour on the shelf.' },
]
