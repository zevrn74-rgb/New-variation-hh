import type { Review } from '../types'

export const reviews: Review[] = [
  { id: 'rv1', bookId: 'bk_atomic_habits', customerName: 'Ananya R.', rating: 5, body: 'I marked one chapter a week and actually kept a habit past the mid-sem crash. The environment chapter is the one I reread.', date: '2026-08-12', verified: true, status: 'approved' },
  { id: 'rv2', bookId: 'bk_atomic_habits', customerName: 'Dev M.', rating: 5, body: 'Less magic than the title suggests, which is why it works. Clear systems, no incense.', date: '2026-07-02', verified: true, status: 'approved' },
  { id: 'rv3', bookId: 'bk_psychology_money', customerName: 'Priya S.', rating: 5, body: 'The chapter on “enough” is the one I sent my brother. Quiet book, expensive lesson.', date: '2026-08-21', verified: true, status: 'approved' },
  { id: 'rv4', bookId: 'bk_good_strategy', customerName: 'Karthik N.', rating: 5, body: 'Killed a slide deck I was proud of. That is a recommendation.', date: '2026-06-18', verified: true, status: 'approved' },
  { id: 'rv5', bookId: 'bk_deep_work', customerName: 'Meera J.', rating: 4, body: 'Severe in a useful way. Shutdown ritual lasted longer than the social media rules.', date: '2026-05-30', verified: true, status: 'approved' },
  { id: 'rv6', bookId: 'bk_wings_of_fire', customerName: 'Rahul K.', rating: 5, body: 'Bought a second copy for a cousin before board exams. The teacher chapters still land.', date: '2026-04-11', verified: true, status: 'approved' },
  { id: 'rv7', bookId: 'bk_pride', customerName: 'Sana F.', rating: 5, body: 'Funniest book I have read that is also on a syllabus. Elizabeth Bennet does not waste a sentence.', date: '2026-07-19', verified: true, status: 'approved' },
  { id: 'rv8', bookId: 'bk_thinking_fast', customerName: 'Arjun P.', rating: 4, body: 'Slow in the good way. Take notes. Do not pretend you will remember the names of the biases.', date: '2026-03-22', verified: true, status: 'approved' },
  { id: 'rv9', bookId: 'bk_man_search', customerName: 'Niharika T.', rating: 5, body: 'I do not recommend this lightly. I do recommend it. Read it when you can sit still.', date: '2026-02-14', verified: true, status: 'approved' },
  { id: 'rv10', bookId: 'bk_this_is_marketing', customerName: 'Ishaan V.', rating: 5, body: 'Used the smallest viable audience idea on a campus fest page. Fewer followers, more ticket sales.', date: '2026-08-03', verified: true, status: 'approved' },
  { id: 'rv11', bookId: 'bk_gruffalo', customerName: 'Asha L.', rating: 5, body: 'Fourth copy in the house. The rhyme is a trap and we walked into it happily.', date: '2026-06-09', verified: true, status: 'approved' },
  { id: 'rv12', bookId: 'bk_sapiens', customerName: 'Vikram D.', rating: 4, body: 'Sweeping, argumentative, and a good fight to have with a reading group.', date: '2026-05-01', verified: true, status: 'approved' },
]
