import type { SiteSettings } from '../types'

export const defaultSite: SiteSettings = {
  storeName: 'Lumen Folio',
  tagline: 'Intelligent books for curious lives.',
  description:
    'An independent bookstore in Bengaluru. We buy well-made editions at trade price and sell them one copy at a time to students, working readers, and the people who shop for them.',
  phone: '+91 80 4123 8800',
  email: 'hello@lumenfolio.in',
  whatsapp: '+91 98765 43210',
  address: '14 Church Street, Shivajinagar, Bengaluru 560001',
  copyright: '© 2026 Lumen Folio. An independent bookshop.',
  logoText: 'Lumen Folio',
  social: {
    instagram: 'https://instagram.com/lumenfolio',
    twitter: 'https://x.com/lumenfolio',
    youtube: 'https://youtube.com/@lumenfolio',
  },
  colors: {
    ink: '#161412',
    paper: '#F4EFE6',
    cream: '#FBF7F0',
    clay: '#B85C38',
    forest: '#243F35',
    gold: '#C4A574',
  },
  fonts: { heading: 'Fraunces', body: 'Source Sans 3' },
  announcement: {
    enabled: true,
    text: 'Free shipping across India on orders above ₹799 · Students: use STUDENT15 this season',
    link: '/deals',
  },
  seo: {
    title: 'Lumen Folio — Independent bookstore for curious readers',
    description:
      'Buy business, marketing, psychology, fiction, and children’s books from an independent Indian bookstore. Thoughtful editions. Fair prices. Ships nationwide.',
    ogImage: '/og.jpg',
  },
  hero: {
    headline: 'Books chosen like a good conversation.',
    subheadline:
      'We stock fewer titles than a warehouse and stand behind every one. Business, minds, stories, and the first books a child will memorize.',
    primaryCta: 'Browse the shop',
    primaryHref: '/shop',
    secondaryCta: 'This week’s table',
    secondaryHref: '/new',
    alignment: 'left',
  },
  sectionVisibility: {
    announcement: true,
    hero: true,
    categories: true,
    newArrivals: true,
    bestsellers: true,
    deals: true,
    featured: true,
    business: true,
    selfhelp: true,
    fiction: true,
    reviews: true,
    why: true,
    newsletter: true,
    cta: true,
  },
  footerText:
    'Lumen Folio is a working bookshop, not a catalogue with a pulse. If a title is on this site, we have read enough of it to know why it is here.',
  upiId: '8384059345@fam',
  upiName: 'Lumen Folio',
}
