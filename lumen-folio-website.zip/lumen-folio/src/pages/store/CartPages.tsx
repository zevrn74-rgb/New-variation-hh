import { useState } from 'react'
import { useApp } from '../../store/AppState'
import { Link, useRouter } from '../../lib/router'
import { BookCover } from '../../components/store/BookCover'
import { cartLines } from '../../lib/coupons'
import { formatMoney } from '../../lib/format'
import { PageHead } from '../../components/store/StoreShell'
import { upiPayUrl } from '../../lib/upi'

const RAZORPAY_KEY = import.meta.env.VITE_RAZORPAY_KEY_ID as string | undefined

export function CartPage() {
  const { cart, books, updateQty, removeFromCart, saveForLater, moveToCart, applyCode, clearCoupon, appliedCoupon, totals } = useApp()
  const [code, setCode] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const active = cartLines(cart, books)
  const later = cart.filter((i) => i.savedForLater).map((i) => ({ item: i, book: books.find((b) => b.id === i.bookId) })).filter((x) => x.book)

  return (
    <>
      <PageHead kicker="Bag" title="Your bag" />
      <div className="container cart-layout">
        <div>
          {!active.length && <div className="empty">The bag is empty. <Link href="/shop" className="link">Open the shop</Link></div>}
          {active.map(({ book, qty }) => (
            <div key={book.id} className="line-item">
              <Link href={`/book/${book.slug}`}><BookCover book={book} /></Link>
              <div>
                <Link href={`/book/${book.slug}`} className="serif">{book.title}</Link>
                <div className="muted">{book.author}</div>
                <div className="row" style={{ marginTop: 8 }}>
                  <div className="qty">
                    <button onClick={() => updateQty(book.id, qty - 1)}>−</button>
                    <span>{qty}</span>
                    <button onClick={() => updateQty(book.id, qty + 1)}>+</button>
                  </div>
                  <button className="btn ghost" onClick={() => saveForLater(book.id)}>Save for later</button>
                  <button className="btn ghost" onClick={() => removeFromCart(book.id)}>Remove</button>
                </div>
              </div>
              <strong>{formatMoney((book.salePrice ?? book.price) * qty)}</strong>
            </div>
          ))}
          {later.length > 0 && (
            <>
              <h3 style={{ marginTop: 28 }}>Saved for later</h3>
              {later.map(({ item, book }) => book && (
                <div key={book.id} className="line-item">
                  <BookCover book={book} />
                  <div>
                    <div className="serif">{book.title}</div>
                    <button className="btn ghost" onClick={() => moveToCart(book.id)}>Move to bag</button>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
        <aside className="panel">
          <h3>Summary</h3>
          <p className="row" style={{ justifyContent: 'space-between' }}><span>Subtotal</span><span>{formatMoney(totals.subtotal)}</span></p>
          <p className="row" style={{ justifyContent: 'space-between' }}><span>Discount</span><span>− {formatMoney(totals.discount)}</span></p>
          <p className="row" style={{ justifyContent: 'space-between' }}><span>Shipping</span><span>{totals.shipping === 0 ? 'Free' : formatMoney(totals.shipping)}</span></p>
          <p className="row" style={{ justifyContent: 'space-between', marginTop: 8 }}><strong>Total</strong><strong>{formatMoney(totals.total)}</strong></p>
          <div className="space" />
          <div className="row">
            <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Coupon code" style={{ flex: 1, padding: 10, border: '1px solid var(--line-strong)' }} />
            <button className="btn ghost" onClick={() => setErr(applyCode(code))}>Apply</button>
          </div>
          {appliedCoupon && <p className="tiny">Applied {appliedCoupon.code} <button className="link" onClick={clearCoupon}>Remove</button></p>}
          {err && <p className="warn">{err}</p>}
          <div className="space" />
          <Link href="/checkout" className="btn wide">Checkout</Link>
        </aside>
      </div>
    </>
  )
}

export function CheckoutPage() {
  const { session, totals, placeOrder, track, cart, books, site } = useApp()
  const { navigate } = useRouter()
  const [form, setForm] = useState({
    name: session?.name ?? '',
    email: session?.email ?? '',
    phone: session?.phone ?? '',
    line1: session?.addresses[0]?.line1 ?? '',
    city: session?.addresses[0]?.city ?? '',
    state: session?.addresses[0]?.state ?? 'Karnataka',
    pincode: session?.addresses[0]?.pincode ?? '',
  })
  const [method, setMethod] = useState<'cod' | 'upi' | 'razorpay'>('upi')
  const [upiRef, setUpiRef] = useState('')
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const upiId = site.upiId || '8384059345@fam'
  const upiName = site.upiName || 'Lumen Folio'

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }))

  const address = {
    label: 'Shipping' as const,
    name: form.name,
    phone: form.phone,
    line1: form.line1,
    city: form.city,
    state: form.state,
    pincode: form.pincode,
  }

  const submitCod = () => {
    const result = placeOrder({
      name: form.name, email: form.email, phone: form.phone,
      address, paymentMethod: 'cod', paymentStatus: 'pending',
    })
    if (typeof result === 'string') { setError(result); return }
    navigate(`/order/${result.id}`)
  }

  const submitUpi = () => {
    const result = placeOrder({
      name: form.name, email: form.email, phone: form.phone,
      address, paymentMethod: 'upi', paymentStatus: 'pending',
      upiRef: upiRef.trim() || undefined,
    })
    if (typeof result === 'string') { setError(result); return }
    navigate(`/order/${result.id}`)
  }

  const payOnline = async () => {
    if (!RAZORPAY_KEY) {
      setError('Online payments need VITE_RAZORPAY_KEY_ID and a server-side verification function. Cash on delivery is available now.')
      return
    }
    setBusy(true)
    track({ name: 'checkout_start' })
    const options = {
      key: RAZORPAY_KEY,
      amount: totals.total * 100,
      currency: 'INR',
      name: 'Lumen Folio',
      description: 'Book order',
      handler: async (response: { razorpay_payment_id: string; razorpay_order_id: string; razorpay_signature: string }) => {
        const verifyUrl = import.meta.env.VITE_VERIFY_PAYMENT_URL as string | undefined
        if (!verifyUrl) {
          setError('Payment was collected in Razorpay but this site has no verify endpoint configured. Order was not created.')
          setBusy(false)
          return
        }
        const verified = await fetch(verifyUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(response),
        }).then((r) => r.json()).catch(() => ({ ok: false }))
        if (!verified?.ok) {
          setError('We could not verify that payment. No order was placed.')
          setBusy(false)
          return
        }
        const result = placeOrder({
          name: form.name, email: form.email, phone: form.phone,
          address: { label: 'Shipping', name: form.name, phone: form.phone, line1: form.line1, city: form.city, state: form.state, pincode: form.pincode },
          paymentMethod: 'razorpay', paymentStatus: 'paid', paymentId: response.razorpay_payment_id,
        })
        if (typeof result === 'string') { setError(result); setBusy(false); return }
        navigate(`/order/${result.id}`)
      },
      prefill: { name: form.name, email: form.email, contact: form.phone },
      theme: { color: '#243F35' },
      modal: { ondismiss: () => setBusy(false) },
    }
    const existing = document.getElementById('rzp-script')
    const boot = () => {
      const Razorpay = (window as unknown as { Razorpay: new (o: typeof options) => { open: () => void } }).Razorpay
      new Razorpay(options).open()
    }
    if (existing) boot()
    else {
      const s = document.createElement('script')
      s.id = 'rzp-script'
      s.src = 'https://checkout.razorpay.com/v1/checkout.js'
      s.onload = boot
      document.body.appendChild(s)
    }
  }

  if (!cartLines(cart, books).length) {
    return <div className="container empty">Nothing to check out. <Link href="/shop" className="link">Shop</Link></div>
  }

  return (
    <>
      <PageHead kicker="Checkout" title="Where should it go?" />
      <div className="container checkout-layout">
        <form className="panel" onSubmit={(e) => { e.preventDefault(); track({ name: 'checkout_start' }); method === 'cod' ? submitCod() : method === 'upi' ? submitUpi() : payOnline() }}>
          <div className="field"><label>Name</label><input required value={form.name} onChange={(e) => set('name', e.target.value)} /></div>
          <div className="space" />
          <div className="field"><label>Mobile</label><input required value={form.phone} onChange={(e) => set('phone', e.target.value)} /></div>
          <div className="space" />
          <div className="field"><label>Email</label><input required type="email" value={form.email} onChange={(e) => set('email', e.target.value)} /></div>
          <div className="space" />
          <div className="field"><label>Address</label><input required value={form.line1} onChange={(e) => set('line1', e.target.value)} /></div>
          <div className="space" />
          <div className="row">
            <div className="field grow"><label>City</label><input required value={form.city} onChange={(e) => set('city', e.target.value)} /></div>
            <div className="field grow"><label>State</label><input required value={form.state} onChange={(e) => set('state', e.target.value)} /></div>
            <div className="field grow"><label>Pincode</label><input required value={form.pincode} onChange={(e) => set('pincode', e.target.value)} /></div>
          </div>
          <div className="space-lg" />
          <div className="tiny">Payment</div>
          <label className="row"><input type="radio" checked={method === 'upi'} onChange={() => setMethod('upi')} /> UPI — {upiId}</label>
          <label className="row"><input type="radio" checked={method === 'cod'} onChange={() => setMethod('cod')} /> Cash on delivery</label>
          <label className="row"><input type="radio" checked={method === 'razorpay'} onChange={() => setMethod('razorpay')} /> Cards / netbanking (Razorpay)</label>
          {method === 'upi' && (
            <div className="panel" style={{ marginTop: 12, background: 'var(--paper)' }}>
              <p className="tiny">Pay exactly {formatMoney(totals.total)}</p>
              <p className="serif" style={{ fontSize: 22, margin: '8px 0' }}>{upiId}</p>
              <p className="muted">Name on UPI: {upiName}</p>
              <div className="row" style={{ marginTop: 12 }}>
                <button type="button" className="btn ghost" onClick={() => {
                  navigator.clipboard.writeText(upiId).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1600) })
                }}>{copied ? 'Copied' : 'Copy UPI ID'}</button>
                <a className="btn" href={upiPayUrl({ pa: upiId, pn: upiName, amount: totals.total, note: 'Lumen Folio order' })}>
                  Open UPI app
                </a>
              </div>
              <div className="space" />
              <div className="field">
                <label>UTR / UPI reference (optional)</label>
                <input value={upiRef} onChange={(e) => setUpiRef(e.target.value)} placeholder="12-digit UTR after you pay" />
              </div>
              <p className="tiny" style={{ marginTop: 8 }}>The order stays unpaid until the shop confirms the money in the UPI app. Do not mark it paid yourself.</p>
            </div>
          )}
          {error && <p className="warn">{error}</p>}
          <div className="space" />
          <button className="btn wide" disabled={busy} type="submit">
            {method === 'cod' ? `Place COD order · ${formatMoney(totals.total)}` : method === 'upi' ? `I have paid ${formatMoney(totals.total)} by UPI` : `Pay ${formatMoney(totals.total)}`}
          </button>
        </form>
        <aside className="panel">
          <h3>To pay</h3>
          <p className="row" style={{ justifyContent: 'space-between' }}><span>Subtotal</span>{formatMoney(totals.subtotal)}</p>
          <p className="row" style={{ justifyContent: 'space-between' }}><span>Discount</span>− {formatMoney(totals.discount)}</p>
          <p className="row" style={{ justifyContent: 'space-between' }}><span>Shipping</span>{totals.shipping === 0 ? 'Free' : formatMoney(totals.shipping)}</p>
          <p className="row" style={{ justifyContent: 'space-between' }}><strong>Total</strong><strong>{formatMoney(totals.total)}</strong></p>
          <p className="tiny" style={{ marginTop: 12 }}>Online orders are created only after the payment signature is verified on the server.</p>
        </aside>
      </div>
    </>
  )
}

export function WishlistPage() {
  const { wishlist, books } = useApp()
  const list = books.filter((b) => wishlist.includes(b.id))
  return (
    <>
      <PageHead kicker="Saved" title="Wishlist" />
      <div className="container section" style={{ paddingTop: 8 }}>
        {list.length ? <div className="book-grid">{list.map((b) => <Link key={b.id} href={`/book/${b.slug}`} className="book-card"><span className="title">{b.title}</span><span className="author">{b.author}</span></Link>)}</div> : <div className="empty">Nothing saved yet.</div>}
        {list.length > 0 && (
          <div className="book-grid">
            {list.map((b) => (
              <Link key={b.id} href={`/book/${b.slug}`} className="panel">
                <div className="serif">{b.title}</div>
                <div className="muted">{b.author}</div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  )
}

export function TrackPage() {
  const { orders } = useApp()
  const { query, navigate } = useRouter()
  const [q, setQ] = useState(query.get('id') ?? '')
  const found = orders.find((o) => o.orderNumber.toLowerCase() === q.trim().toLowerCase() || o.id === q.trim())
  const steps = ['placed', 'confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered'] as const
  return (
    <>
      <PageHead kicker="Orders" title="Track an order" />
      <div className="container section" style={{ paddingTop: 8, maxWidth: 640 }}>
        <form className="search-bar" onSubmit={(e) => { e.preventDefault(); navigate(`/track-order?id=${encodeURIComponent(q)}`) }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Order ID, e.g. LF-24018" />
          <button className="btn" type="submit">Track</button>
        </form>
        {q && !found && <p className="warn" style={{ marginTop: 16 }}>No order with that ID.</p>}
        {found && <OrderView orderId={found.id} />}
        {!found && steps && null}
      </div>
    </>
  )
}

export function OrderView({ orderId }: { orderId: string }) {
  const { orders, site } = useApp()
  const order = orders.find((o) => o.id === orderId)
  if (!order) return <div className="container empty">Order not found.</div>
  const flow = ['placed', 'confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered']
  const current = order.status
  return (
    <div className="container section">
      <div className="kicker">{order.orderNumber}</div>
      <h1 style={{ fontSize: 36 }}>{order.status.replace(/_/g, ' ')}</h1>
      <p className="muted">{order.customerName} · {formatMoney(order.total)} · {order.paymentMethod === 'cod' ? 'Cash on delivery' : order.paymentMethod === 'upi' ? 'UPI' : 'Online'} ({order.paymentStatus})</p>
      {order.paymentMethod === 'upi' && (
        <p className="muted" style={{ marginTop: 8 }}>
          Pay to {site.upiId || '8384059345@fam'} · {order.upiRef ? `UTR ${order.upiRef}` : 'Waiting for shop to confirm the UPI credit'}
        </p>
      )}
      <div className="space-lg" />
      <div className="timeline">
        {flow.map((s) => (
          <div key={s} className={`t-step ${flow.indexOf(s) <= flow.indexOf(current) || current === s ? 'done' : ''}`}>
            <div className="dot" />
            <div>
              <strong>{s.replace(/_/g, ' ')}</strong>
              <div className="tiny">{order.timeline.find((t) => t.status === s)?.at ?? ''}</div>
            </div>
          </div>
        ))}
      </div>
      {['cancelled', 'returned', 'refunded'].includes(order.status) && <p className="warn">This order is {order.status}.</p>}
      <div className="space-lg" />
      <h3>Books</h3>
      {order.items.map((i) => <p key={i.bookId}>{i.qty} × {i.title} · {formatMoney(i.lineTotal)}</p>)}
      <div className="space" />
      <h3>Deliver to</h3>
      <p>{order.address.line1}, {order.address.city}, {order.address.state} {order.address.pincode}</p>
    </div>
  )
}
