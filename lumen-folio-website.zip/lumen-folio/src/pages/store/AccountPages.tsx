import { useState } from 'react'
import { useApp } from '../../store/AppState'
import { Link, useRouter } from '../../lib/router'
import { formatDate, formatMoney } from '../../lib/format'
import { PageHead } from '../../components/store/StoreShell'

export function LoginPage({ mode }: { mode: 'login' | 'register' | 'forgot' }) {
  const { login, register, toast } = useApp()
  const { navigate } = useRouter()
  const [err, setErr] = useState<string | null>(null)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')

  const onLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    const msg = await login(email, password)
    if (msg) setErr(msg)
    else navigate('/account')
  }
  const onRegister = (e: React.FormEvent) => {
    e.preventDefault()
    const msg = register(name, email, phone, password)
    if (msg) setErr(msg)
    else navigate('/account')
  }

  return (
    <>
      <PageHead kicker="Account" title={mode === 'register' ? 'Create an account' : mode === 'forgot' ? 'Reset a password' : 'Sign in'} />
      <div className="container" style={{ maxWidth: 480, paddingBottom: 48 }}>
        {mode === 'forgot' ? (
          <form className="panel" onSubmit={(e) => { e.preventDefault(); toast('If that email exists, a reset link would be sent by Supabase Auth.'); }}>
            <div className="field"><label>Email</label><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            <div className="space" />
            <button className="btn wide">Send reset link</button>
          </form>
        ) : (
          <form className="panel" onSubmit={mode === 'login' ? onLogin : onRegister}>
            {mode === 'register' && <><div className="field"><label>Name</label><input required value={name} onChange={(e) => setName(e.target.value)} /></div><div className="space" /></>}
            <div className="field"><label>Email</label><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            <div className="space" />
            {mode === 'register' && <><div className="field"><label>Mobile</label><input required value={phone} onChange={(e) => setPhone(e.target.value)} /></div><div className="space" /></>}
            <div className="field"><label>Password</label><input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
            {err && <p className="warn">{err}</p>}
            <div className="space" />
            <button className="btn wide">{mode === 'login' ? 'Sign in' : 'Create account'}</button>
          </form>
        )}
        <div className="space" />
        {mode === 'login' && <p className="muted"><Link href="/register" className="link">Create an account</Link> · <Link href="/forgot-password" className="link">Forgot password</Link></p>}
        {mode === 'register' && <p className="muted">Already here? <Link href="/login" className="link">Sign in</Link></p>}
      </div>
    </>
  )
}

export function AccountPage() {
  const { session, logout, orders, updateProfile, saveAddress } = useApp()
  const { path, navigate } = useRouter()
  if (!session) {
    return (
      <div className="container empty">
        <p>Sign in to see orders and addresses.</p>
        <div className="space" />
        <Link href="/login" className="btn">Sign in</Link>
      </div>
    )
  }
  const mine = orders.filter((o) => o.email === session.email || o.customerId === session.id)
  const section = path.includes('/orders') ? 'orders' : path.includes('/wishlist') ? 'wish' : 'profile'

  return (
    <div className="container account-grid">
      <aside>
        <div className="tiny">Signed in</div>
        <h3 className="serif">{session.name}</h3>
        <Link href="/account" className="side-link">Profile</Link>
        <Link href="/account/orders" className="side-link">Orders</Link>
        <Link href="/wishlist" className="side-link">Wishlist</Link>
        <button className="side-link" onClick={() => { logout(); navigate('/') }}>Log out</button>
      </aside>
      <div>
        {section !== 'orders' && (
          <>
            <h2>Profile</h2>
            <div className="space" />
            <form className="panel" onSubmit={(e) => { e.preventDefault(); const fd = new FormData(e.currentTarget); updateProfile({ name: String(fd.get('name')), phone: String(fd.get('phone')) }) }}>
              <div className="field"><label>Name</label><input name="name" defaultValue={session.name} /></div>
              <div className="space" />
              <div className="field"><label>Email</label><input defaultValue={session.email} disabled /></div>
              <div className="space" />
              <div className="field"><label>Phone</label><input name="phone" defaultValue={session.phone} /></div>
              <div className="space" />
              <button className="btn">Save profile</button>
            </form>
            <div className="space-lg" />
            <h2>Addresses</h2>
            {session.addresses.map((a) => <div key={a.id} className="panel" style={{ marginTop: 8 }}>{a.line1}, {a.city} {a.pincode}</div>)}
            <form className="panel" style={{ marginTop: 8 }} onSubmit={(e) => {
              e.preventDefault()
              const fd = new FormData(e.currentTarget)
              saveAddress({
                id: crypto.randomUUID(), label: 'Home', name: session.name, phone: session.phone,
                line1: String(fd.get('line1')), city: String(fd.get('city')), state: String(fd.get('state')), pincode: String(fd.get('pincode')),
              })
              e.currentTarget.reset()
            }}>
              <div className="field"><label>Street</label><input name="line1" required /></div>
              <div className="space" />
              <div className="row">
                <div className="field grow"><label>City</label><input name="city" required /></div>
                <div className="field grow"><label>State</label><input name="state" required /></div>
                <div className="field grow"><label>Pincode</label><input name="pincode" required /></div>
              </div>
              <div className="space" />
              <button className="btn ghost">Add address</button>
            </form>
          </>
        )}
        {section === 'orders' && (
          <>
            <h2>Orders</h2>
            <div className="space" />
            {!mine.length && <p className="muted">No orders yet.</p>}
            {mine.map((o) => (
              <Link key={o.id} href={`/order/${o.id}`} className="panel" style={{ display: 'block', marginBottom: 8 }}>
                <strong>{o.orderNumber}</strong>
                <div className="muted">{formatDate(o.createdAt)} · {o.status} · {formatMoney(o.total)}</div>
              </Link>
            ))}
          </>
        )}
      </div>
    </div>
  )
}
