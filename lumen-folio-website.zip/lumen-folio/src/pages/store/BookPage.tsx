import { useEffect, useState } from 'react'
import { useApp } from '../../store/AppState'
import { useRouter } from '../../lib/router'
import { BookCover } from '../../components/store/BookCover'
import { BookRail, Stars } from '../../components/store/BookCard'
import { discountPct, effectivePrice, formatMoney } from '../../lib/format'

export function BookPage({ slug }: { slug: string }) {
  const { books, reviews, addToCart, toggleWishlist, wishlist, viewBook, recentlyViewed } = useApp()
  const { navigate } = useRouter()
  const book = books.find((b) => b.slug === slug)
  const [qty, setQty] = useState(1)
  const [tab, setTab] = useState<'desc' | 'author' | 'specs'>('desc')

  useEffect(() => {
    if (book) viewBook(book.id)
  }, [book?.id])

  if (!book) return <div className="container empty">We do not have that title.</div>

  const sale = effectivePrice(book.price, book.salePrice)
  const off = discountPct(book.price, book.salePrice)
  const available = book.stock - book.reserved
  const related = books.filter((b) => b.published && b.categoryId === book.categoryId && b.id !== book.id).slice(0, 4)
  const together = books.filter((b) => b.published && b.id !== book.id && b.bestseller).slice(0, 3)
  const recent = recentlyViewed.map((id) => books.find((b) => b.id === id)).filter(Boolean).filter((b) => b && b.id !== book.id) as typeof books
  const bookReviews = reviews.filter((r) => r.bookId === book.id && r.status === 'approved')

  const buyNow = () => {
    addToCart(book.id, qty)
    navigate('/checkout')
  }

  return (
    <>
      <div className="container product">
        <div>
          <BookCover book={book} />
          <div className="space" />
          <div className="tiny">Editorial cover · ISBN {book.isbn}</div>
        </div>
        <div>
          <div className="kicker">Book</div>
          <h1>{book.title}</h1>
          <p className="muted">{book.author}</p>
          <div className="row" style={{ marginTop: 8 }}>
            <Stars value={book.rating} />
            <span className="muted">{book.rating} · {book.reviewCount} reviews</span>
          </div>
          <div className="price" style={{ marginTop: 16, fontSize: 20 }}>
            <strong>{formatMoney(sale)}</strong>
            {off > 0 && <span className="was">{formatMoney(book.price)}</span>}
            {off > 0 && <span className="off">{off}% off</span>}
          </div>
          <p style={{ marginTop: 16 }}>{book.description}</p>
          <p className="tiny" style={{ marginTop: 10 }}>{available > 0 ? `${available} available` : 'Out of stock'}</p>
          <div className="row" style={{ marginTop: 16 }}>
            <div className="qty" aria-label="Quantity">
              <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))}>−</button>
              <span>{qty}</span>
              <button type="button" onClick={() => setQty((q) => q + 1)}>+</button>
            </div>
            <button className="btn" disabled={available <= 0} onClick={() => addToCart(book.id, qty)}>Add to bag</button>
            <button className="btn clay" disabled={available <= 0} onClick={buyNow}>Buy now</button>
            <button className="btn ghost" onClick={() => toggleWishlist(book.id)}>{wishlist.includes(book.id) ? 'Saved' : 'Save'}</button>
          </div>
          <div className="space-lg" />
          <div className="chip-row">
            <button className={`chip ${tab === 'desc' ? 'on' : ''}`} onClick={() => setTab('desc')}>Description</button>
            <button className={`chip ${tab === 'author' ? 'on' : ''}`} onClick={() => setTab('author')}>About the author</button>
            <button className={`chip ${tab === 'specs' ? 'on' : ''}`} onClick={() => setTab('specs')}>Details</button>
          </div>
          <div className="space" />
          {tab === 'desc' && <p className="muted">{book.longDescription}</p>}
          {tab === 'author' && <p className="muted">{book.authorBio}</p>}
          {tab === 'specs' && (
            <dl className="muted">
              <p>Publisher · {book.publisher}</p>
              <p>ISBN · {book.isbn}</p>
              <p>Language · {book.language}</p>
              <p>Pages · {book.pages}</p>
              <p>Format · {book.format}</p>
              <p>Dimensions · {book.dimensions}</p>
              <p>Published · {book.publishedAt}</p>
              <p>SKU · {book.sku}</p>
              <p>Tags · {book.tags.join(', ')}</p>
            </dl>
          )}
        </div>
      </div>

      <div className="container section" style={{ paddingTop: 0 }}>
        <h2>Reviews</h2>
        <div className="space" />
        {bookReviews.length === 0 && <p className="muted">No published reviews yet.</p>}
        {bookReviews.map((r) => (
          <div key={r.id} className="panel" style={{ marginBottom: 10 }}>
            <div className="row"><Stars value={r.rating} /><strong>{r.customerName}</strong>{r.verified && <span className="tag">Verified purchase</span>}</div>
            <p style={{ marginTop: 8 }}>{r.body}</p>
            <div className="tiny">{r.date}</div>
          </div>
        ))}
      </div>

      {together.length > 0 && (
        <div className="container section">
          <div className="section-head"><h2>Frequently bought together</h2></div>
          <BookRail books={together} />
        </div>
      )}
      {related.length > 0 && (
        <div className="container section">
          <div className="section-head"><h2>Related books</h2></div>
          <BookRail books={related} />
        </div>
      )}
      {recent.length > 0 && (
        <div className="container section">
          <div className="section-head"><h2>Recently viewed</h2></div>
          <BookRail books={recent.slice(0, 4)} />
        </div>
      )}

      <div className="sticky-buy">
        <div>
          <strong>{book.title}</strong>
          <div>{formatMoney(sale)}</div>
        </div>
        <button className="btn" disabled={available <= 0} onClick={() => addToCart(book.id, qty)}>Add</button>
      </div>
    </>
  )
}
