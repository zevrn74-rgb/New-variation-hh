import { useState } from 'react'
import { useApp } from '../../store/AppState'
import { Link } from '../../lib/router'
import { BookRail } from '../../components/store/BookCard'
import { IconBook, IconShield, IconTruck } from '../../components/icons'

export function HomePage() {
  const { site, books, categories, reviews } = useApp()
  const vis = site.sectionVisibility
  const live = books.filter((b) => b.published)
  const featuredCats = categories.filter((c) => c.featured && !c.hidden).slice(0, 8)
  const [email, setEmail] = useState('')
  const [joined, setJoined] = useState(false)
  return (
    <>
      {vis.hero && (
        <section className="container hero">
          <div>
            <div className="kicker">Independent bookshop · Bengaluru</div>
            <h1>{site.hero.headline}</h1>
            <p className="lead">{site.hero.subheadline}</p>
            <div className="hero-actions">
              <Link href={site.hero.primaryHref} className="btn">{site.hero.primaryCta}</Link>
              <Link href={site.hero.secondaryHref} className="btn ghost">{site.hero.secondaryCta}</Link>
            </div>
          </div>
          <div className="hero-panel">
            <div className="tiny" style={{ color: 'var(--gold)' }}>On the table this week</div>
            <div className="big">Fewer titles. Better reasons.</div>
            <p style={{ marginTop: 12, maxWidth: '32ch', opacity: 0.85 }}>
              We buy at trade price and sell one copy at a time. If it is here, someone in the shop can tell you why.
            </p>
          </div>
        </section>
      )}

      {vis.categories && (
        <section className="container section">
          <div className="section-head">
            <h2>Shelves</h2>
            <Link href="/categories">All categories</Link>
          </div>
          <div className="grid-cats">
            {featuredCats.map((c) => (
              <Link key={c.id} href={`/shop?category=${c.slug}`} className="cat-tile" style={{ background: c.imageTone }}>
                <p>{c.description}</p>
                <h3>{c.name}</h3>
              </Link>
            ))}
          </div>
        </section>
      )}

      {vis.newArrivals && (
        <section className="container section">
          <div className="section-head">
            <h2>New arrivals</h2>
            <Link href="/new">View all</Link>
          </div>
          <BookRail books={live.filter((b) => b.newArrival).slice(0, 4)} />
        </section>
      )}

      {vis.bestsellers && (
        <section className="band">
          <div className="container section">
            <div className="section-head">
              <h2>Bestsellers</h2>
              <Link href="/bestsellers">View all</Link>
            </div>
            <BookRail books={live.filter((b) => b.bestseller).slice(0, 4)} />
          </div>
        </section>
      )}

      {vis.deals && (
        <section className="container section">
          <div className="section-head">
            <h2>Deals on the table</h2>
            <Link href="/deals">All offers</Link>
          </div>
          <BookRail books={live.filter((b) => b.salePrice && b.salePrice < b.price).slice(0, 4)} />
        </section>
      )}

      {vis.featured && (
        <section className="container section">
          <div className="section-head">
            <h2>Staff table</h2>
          </div>
          <BookRail books={live.filter((b) => b.featured).slice(0, 4)} />
        </section>
      )}

      {vis.business && (
        <section className="band">
          <div className="container section">
            <div className="section-head">
              <h2>Business & marketing</h2>
              <Link href="/shop?category=business">Browse</Link>
            </div>
            <BookRail books={live.filter((b) => ['cat_business', 'cat_marketing'].includes(b.categoryId)).slice(0, 4)} />
          </div>
        </section>
      )}

      {vis.selfhelp && (
        <section className="container section">
          <div className="section-head">
            <h2>Self-help & minds</h2>
            <Link href="/shop?category=self-help">Browse</Link>
          </div>
          <BookRail books={live.filter((b) => ['cat_selfhelp', 'cat_psychology', 'cat_productivity'].includes(b.categoryId)).slice(0, 4)} />
        </section>
      )}

      {vis.fiction && (
        <section className="container section">
          <div className="section-head">
            <h2>Fiction & classics</h2>
            <Link href="/shop?category=fiction">Browse</Link>
          </div>
          <BookRail books={live.filter((b) => ['cat_fiction', 'cat_classics'].includes(b.categoryId)).slice(0, 4)} />
        </section>
      )}

      {vis.reviews && (
        <section className="band">
          <div className="container section">
            <div className="section-head"><h2>From readers</h2></div>
            <div className="review-grid">
              {reviews.filter((r) => r.status === 'approved').slice(0, 3).map((r) => (
                <blockquote key={r.id} className="panel">
                  <div className="stars">★★★★★</div>
                  <p style={{ margin: '10px 0' }}>{r.body}</p>
                  <div className="tiny">{r.customerName}{r.verified ? ' · Verified purchase' : ''}</div>
                </blockquote>
              ))}
            </div>
          </div>
        </section>
      )}

      {vis.why && (
        <section className="container section">
          <div className="section-head"><h2>Why shop with us</h2></div>
          <div className="why-grid">
            <div className="panel"><IconBook /><h3>A list with a spine</h3><p className="muted">We stock fewer books so the ones we keep can be defended in a sentence.</p></div>
            <div className="panel"><IconTruck /><h3>Packed in Bengaluru</h3><p className="muted">Same-day packing before 14:00. Free shipping above ₹799, India-wide.</p></div>
            <div className="panel"><IconShield /><h3>If the copy is wrong</h3><p className="muted">Printing faults and courier damage are replaced. No treasure-hunt policy pages.</p></div>
          </div>
        </section>
      )}

      {vis.newsletter && (
        <section className="container section">
          <form className="newsletter" onSubmit={(e) => { e.preventDefault(); setJoined(true) }}>
            <div>
              <div className="kicker" style={{ color: 'var(--gold)' }}>The Sunday folio</div>
              <h2 style={{ color: 'var(--cream)', fontSize: 36 }}>One letter. A few titles. No slogans.</h2>
            </div>
            <div>
              {joined ? <p>You are on the list.</p> : (
                <>
                  <input type="email" required placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
                  <div className="space" />
                  <button className="btn clay" type="submit">Join the list</button>
                </>
              )}
            </div>
          </form>
        </section>
      )}

      {vis.cta && (
        <section className="container section" style={{ textAlign: 'center' }}>
          <h2>Walk the shop from wherever you are.</h2>
          <p className="muted" style={{ margin: '12px auto 20px', maxWidth: 480 }}>Thirty-six titles on the site today. The rest live on Church Street. If you cannot find a book, write — we will say yes or point you elsewhere.</p>
          <Link href="/shop" className="btn">Open the shop</Link>
        </section>
      )}
    </>
  )
}
