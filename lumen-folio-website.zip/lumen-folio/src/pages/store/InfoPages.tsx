import { staticPages, faqs } from '../../data/pages'
import { useApp } from '../../store/AppState'
import { PageHead } from '../../components/store/StoreShell'

export function InfoPage({ keyName }: { keyName: keyof typeof staticPages }) {
  const page = staticPages[keyName]
  const { site } = useApp()
  return (
    <>
      <PageHead kicker={page.kicker} title={page.title} />
      <div className="container section prose" style={{ paddingTop: 8 }}>
        {page.body.map((p) => <p key={p}>{p}</p>)}
        {keyName === 'contact' && (
          <div className="panel" style={{ marginTop: 16 }}>
            <p>{site.address}</p>
            <p>{site.phone}</p>
            <p>{site.email}</p>
            <p>WhatsApp {site.whatsapp}</p>
            <form style={{ marginTop: 16 }} onSubmit={(e) => e.preventDefault()}>
              <div className="field"><label>Your email</label><input type="email" required /></div>
              <div className="space" />
              <div className="field"><label>Message</label><textarea rows={4} required /></div>
              <div className="space" />
              <button className="btn">Send</button>
            </form>
          </div>
        )}
        {keyName === 'faq' && faqs.map((f) => (
          <details key={f.q} className="panel" style={{ marginBottom: 8 }}>
            <summary className="serif" style={{ cursor: 'pointer' }}>{f.q}</summary>
            <p style={{ marginTop: 8 }}>{f.a}</p>
          </details>
        ))}
      </div>
    </>
  )
}
