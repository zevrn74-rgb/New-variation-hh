import { useMemo, useState } from 'react'
import { useApp } from '../../store/AppState'
import { useRouter } from '../../lib/router'
import { BookRail } from '../../components/store/BookCard'
import { PageHead } from '../../components/store/StoreShell'
import { effectivePrice } from '../../lib/format'
import { IconFilter } from '../../components/icons'
import type { Book } from '../../types'

function sortBooks(list: Book[], sort: string) {
  const copy = [...list]
  if (sort === 'newest') copy.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
  if (sort === 'price_asc') copy.sort((a, b) => effectivePrice(a.price, a.salePrice) - effectivePrice(b.price, b.salePrice))
  if (sort === 'price_desc') copy.sort((a, b) => effectivePrice(b.price, b.salePrice) - effectivePrice(a.price, a.salePrice))
  if (sort === 'bestselling') copy.sort((a, b) => Number(b.bestseller) - Number(a.bestseller) || b.reviewCount - a.reviewCount)
  if (sort === 'rating') copy.sort((a, b) => b.rating - a.rating)
  if (sort === 'featured') copy.sort((a, b) => Number(b.featured) - Number(a.featured))
  return copy
}

export function ShopPage({ mode = 'all' }: { mode?: 'all' | 'new' | 'best' | 'deals' | 'search' | 'cats' }) {
  const { books, categories, track } = useApp()
  const { query, navigate, path } = useRouter()
  const q = query.get('q') ?? ''
  const catSlug = query.get('category') ?? ''
  const [author, setAuthor] = useState('')
  const [maxPrice, setMaxPrice] = useState(1000)
  const [minRating, setMinRating] = useState(0)
  const [onlyIn, setOnlyIn] = useState(false)
  const [sort, setSort] = useState('featured')
  const [filtersOpen, setFiltersOpen] = useState(false)

  const authors = useMemo(() => [...new Set(books.map((b) => b.author))].sort(), [books])

  const filtered = useMemo(() => {
    let list = books.filter((b) => b.published)
    if (mode === 'new') list = list.filter((b) => b.newArrival)
    if (mode === 'best') list = list.filter((b) => b.bestseller)
    if (mode === 'deals') list = list.filter((b) => b.salePrice && b.salePrice < b.price)
    if (catSlug) {
      const cat = categories.find((c) => c.slug === catSlug)
      if (cat) list = list.filter((b) => b.categoryId === cat.id)
    }
    if (q) {
      const s = q.toLowerCase()
      list = list.filter((b) => `${b.title} ${b.author} ${b.tags.join(' ')}`.toLowerCase().includes(s))
    }
    if (author) list = list.filter((b) => b.author === author)
    list = list.filter((b) => effectivePrice(b.price, b.salePrice) <= maxPrice)
    if (minRating) list = list.filter((b) => b.rating >= minRating)
    if (onlyIn) list = list.filter((b) => b.stock - b.reserved > 0)
    return sortBooks(list, sort)
  }, [books, mode, catSlug, q, author, maxPrice, minRating, onlyIn, sort, categories])

  const title =
    mode === 'new' ? 'New arrivals' :
    mode === 'best' ? 'Bestsellers' :
    mode === 'deals' ? 'Deals' :
    mode === 'search' ? (q ? `Results for “${q}”` : 'Search') :
    mode === 'cats' ? 'Categories' :
    catSlug ? (categories.find((c) => c.slug === catSlug)?.name ?? 'Shop') : 'The shop'

  if (mode === 'cats') {
    return (
      <>
        <PageHead kicker="Browse" title="Categories" />
        <div className="container section" style={{ paddingTop: 12 }}>
          <div className="grid-cats">
            {categories.filter((c) => !c.hidden).map((c) => (
              <a key={c.id} href={`/shop?category=${c.slug}`} className="cat-tile" style={{ background: c.imageTone }} onClick={(e) => { e.preventDefault(); navigate(`/shop?category=${c.slug}`) }}>
                <p>{c.description}</p>
                <h3>{c.name}</h3>
              </a>
            ))}
          </div>
        </div>
      </>
    )
  }

  const Filters = (
    <aside className="filters">
      <div className="field">
        <label>Category</label>
        <select value={catSlug} onChange={(e) => navigate(`${path.split('?')[0]}?category=${e.target.value}${q ? `&q=${encodeURIComponent(q)}` : ''}`)}>
          <option value="">All</option>
          {categories.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
        </select>
      </div>
      <div className="field">
        <label>Author</label>
        <select value={author} onChange={(e) => setAuthor(e.target.value)}>
          <option value="">All authors</option>
          {authors.map((a) => <option key={a}>{a}</option>)}
        </select>
      </div>
      <div className="field">
        <label>Max price · ₹{maxPrice}</label>
        <input type="range" min={199} max={1000} value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))} />
      </div>
      <div className="field">
        <label>Minimum rating</label>
        <select value={minRating} onChange={(e) => setMinRating(Number(e.target.value))}>
          <option value={0}>Any</option>
          <option value={4}>4+</option>
          <option value={4.5}>4.5+</option>
        </select>
      </div>
      <label className="row"><input type="checkbox" checked={onlyIn} onChange={(e) => setOnlyIn(e.target.checked)} /> In stock only</label>
    </aside>
  )

  return (
    <>
      <PageHead kicker="Catalogue" title={title}>
        {mode === 'search' && (
          <form className="search-bar" onSubmit={(e) => {
            e.preventDefault()
            const fd = new FormData(e.currentTarget)
            const next = String(fd.get('q') || '')
            track({ name: 'search', query: next })
            navigate(`/search?q=${encodeURIComponent(next)}`)
          }}>
            <input name="q" defaultValue={q} placeholder="Title, author, or idea" aria-label="Search books" />
            <button className="btn" type="submit">Search</button>
          </form>
        )}
      </PageHead>
      <div className="container shop-layout">
        <div className="row" style={{ display: 'none' }} />
        <button className="btn ghost" style={{ display: 'none' }} />
        <div className="only-mobile" />
        {Filters}
        <div>
          <div className="row" style={{ justifyContent: 'space-between', marginBottom: 16 }}>
            <span className="muted">{filtered.length} titles</span>
            <div className="row">
              <button className="btn ghost" onClick={() => setFiltersOpen(true)} style={{ minHeight: 40 }}><IconFilter size={16} /> Filters</button>
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="featured">Featured</option>
                <option value="newest">Newest</option>
                <option value="price_asc">Price: low to high</option>
                <option value="price_desc">Price: high to low</option>
                <option value="bestselling">Bestselling</option>
                <option value="rating">Highest rated</option>
              </select>
            </div>
          </div>
          {filtered.length ? <BookRail books={filtered} /> : <div className="empty">Nothing matched. Try a wider shelf.</div>}
        </div>
      </div>
      {filtersOpen && (
        <>
          <div className="drawer-bg" onClick={() => setFiltersOpen(false)} />
          <div className="drawer" role="dialog" aria-label="Filters">
            {Filters}
            <button className="btn wide" onClick={() => setFiltersOpen(false)}>Show {filtered.length} books</button>
          </div>
        </>
      )}
    </>
  )
}
