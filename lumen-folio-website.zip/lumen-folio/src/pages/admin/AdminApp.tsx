import { useState } from 'react'
import { useApp } from '../../store/AppState'
import { Link, match, useRouter } from '../../lib/router'
import { effectivePrice, formatDate, formatMoney, orderStatusLabel, slugify, uid } from '../../lib/format'
import type { Book, Coupon, OrderStatus, SiteSettings } from '../../types'

const nav = [
  ['/admin/dashboard', 'Dashboard'],
  ['/admin/products', 'Products'],
  ['/admin/categories', 'Categories'],
  ['/admin/inventory', 'Inventory'],
  ['/admin/orders', 'Orders'],
  ['/admin/customers', 'Customers'],
  ['/admin/offers', 'Offers'],
  ['/admin/reviews', 'Reviews'],
  ['/admin/analytics', 'Analytics'],
  ['/admin/website', 'Website editor'],
  ['/admin/media', 'Media'],
  ['/admin/settings', 'Settings'],
  ['/admin/settings/security', 'Security'],
]

export function AdminApp() {
  const { ownerSession } = useApp()
  const { path } = useRouter()
  if (!ownerSession) return <AdminLogin />
  return (
    <div className="admin">
      <aside className="admin-side">
        <div className="logo" style={{ color: 'var(--paper)', padding: '6px 10px 16px' }}>Folio <em style={{ color: 'var(--gold)' }}>Owner</em></div>
        {nav.map(([href, label]) => <Link key={href} href={href}>{label}</Link>)}
        <Link href="/">View store</Link>
      </aside>
      <div className="admin-main">
        {path === '/admin' || path === '/admin/dashboard' ? <Dash /> : null}
        {path === '/admin/products' ? <Products /> : null}
        {path === '/admin/products/new' || match(path, '/admin/products/:id') ? <ProductEdit /> : null}
        {path === '/admin/categories' ? <Categories /> : null}
        {path === '/admin/inventory' ? <Inventory /> : null}
        {path === '/admin/orders' ? <Orders /> : null}
        {match(path, '/admin/orders/:id') ? <OrderEdit /> : null}
        {path === '/admin/customers' ? <Customers /> : null}
        {path === '/admin/offers' ? <Offers /> : null}
        {path === '/admin/reviews' ? <ReviewsAdmin /> : null}
        {path === '/admin/analytics' ? <Analytics /> : null}
        {path === '/admin/website' ? <WebsiteEditor /> : null}
        {path === '/admin/media' ? <Media /> : null}
        {path === '/admin/settings' ? <Settings /> : null}
        {path === '/admin/settings/security' ? <Security /> : null}
      </div>
    </div>
  )
}

function AdminLogin() {
  const { ownerLogin } = useApp()
  const { navigate } = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState<string | null>(null)
  return (
    <div className="container" style={{ maxWidth: 420, padding: '80px 16px' }}>
      <div className="kicker">Owner control center</div>
      <h1>Sign in</h1>
      <form className="panel" style={{ marginTop: 16 }} onSubmit={async (e) => {
        e.preventDefault()
        const msg = await ownerLogin(email, password)
        if (msg) setErr(msg)
        else navigate('/admin/dashboard')
      }}>
        <div className="field"><label>Email</label><input value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="space" />
        <div className="field"><label>Password</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        {err && <p className="warn">{err}</p>}
        <div className="space" />
        <button className="btn wide">Enter</button>
        <p className="tiny" style={{ marginTop: 12 }}>Owner access is checked here in demo mode and must be enforced by Supabase Auth + RLS in production. The password is never stored in the client as plaintext.</p>
      </form>
    </div>
  )
}

function Dash() {
  const { orders, books, customers } = useApp()
  const { navigate } = useRouter()
  const paid = orders.filter((o) => o.paymentStatus === 'paid' || o.status === 'delivered')
  const revenue = paid.reduce((s, o) => s + o.total, 0)
  const pending = orders.filter((o) => ['pending', 'confirmed', 'processing'].includes(o.status)).length
  const low = books.filter((b) => b.stock - b.reserved <= b.lowStockAt && b.stock > 0).length
  const out = books.filter((b) => b.stock - b.reserved <= 0).length
  const today = new Date().toISOString().slice(0, 10)
  const todaySales = orders.filter((o) => o.createdAt.slice(0, 10) === today).reduce((s, o) => s + o.total, 0)
  const month = today.slice(0, 7)
  const monthSales = orders.filter((o) => o.createdAt.slice(0, 7) === month).reduce((s, o) => s + o.total, 0)
  return (
    <>
      <h1>Dashboard</h1>
      <div className="space" />
      <div className="stat-grid">
        <div className="stat">Revenue (paid)<b>{formatMoney(revenue)}</b></div>
        <div className="stat">Orders<b>{orders.length}</b></div>
        <div className="stat">Customers<b>{customers.length}</b></div>
        <div className="stat">Titles<b>{books.length}</b></div>
        <div className="stat">Today<b>{formatMoney(todaySales)}</b></div>
        <div className="stat">This month<b>{formatMoney(monthSales)}</b></div>
        <div className="stat">Pending work<b>{pending}</b></div>
        <div className="stat">Low / out<b>{low} / {out}</b></div>
      </div>
      <div className="space-lg" />
      <div className="row">
        <button className="btn" onClick={() => navigate('/admin/products/new')}>Add book</button>
        <button className="btn ghost" onClick={() => navigate('/admin/offers')}>Create offer</button>
        <button className="btn ghost" onClick={() => navigate('/admin/website')}>Edit homepage</button>
        <button className="btn ghost" onClick={() => navigate('/admin/orders')}>Manage orders</button>
        <button className="btn ghost" onClick={() => navigate('/admin/inventory')}>Inventory</button>
        <button className="btn ghost" onClick={() => navigate('/admin/analytics')}>Analytics</button>
        <button className="btn ghost" onClick={() => navigate('/admin/media')}>Media</button>
      </div>
      <div className="space-lg" />
      <h3>Recent orders</h3>
      <table className="table">
        <thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>
          {orders.slice(0, 6).map((o) => (
            <tr key={o.id}><td><Link href={`/admin/orders/${o.id}`}>{o.orderNumber}</Link></td><td>{o.customerName}</td><td>{formatMoney(o.total)}</td><td>{o.status}</td></tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function Products() {
  const { books, setBooks } = useApp()
  const { navigate } = useRouter()
  const [q, setQ] = useState('')
  const list = books.filter((b) => `${b.title} ${b.author} ${b.sku}`.toLowerCase().includes(q.toLowerCase()))
  return (
    <>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Products</h1>
        <button className="btn" onClick={() => navigate('/admin/products/new')}>Add book</button>
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search title, author, SKU" style={{ margin: '12px 0', width: '100%', padding: 10 }} />
      <table className="table">
        <thead><tr><th>Title</th><th>SKU</th><th>Price</th><th>Stock</th><th>Flags</th><th></th></tr></thead>
        <tbody>
          {list.map((b) => (
            <tr key={b.id}>
              <td><Link href={`/admin/products/${b.id}`}>{b.title}</Link><div className="tiny">{b.author}</div></td>
              <td>{b.sku}</td>
              <td>{formatMoney(effectivePrice(b.price, b.salePrice))}</td>
              <td>{b.stock}</td>
              <td>{[b.featured && 'Featured', b.bestseller && 'Bestseller', b.newArrival && 'New', !b.published && 'Hidden'].filter(Boolean).join(' · ')}</td>
              <td>
                <button className="btn ghost" onClick={() => { setBooks([...books, { ...b, id: uid('bk'), sku: `${b.sku}-COPY`, slug: `${b.slug}-copy`, title: `${b.title} (copy)` }]) }}>Duplicate</button>
                <button className="btn ghost" onClick={() => setBooks(books.filter((x) => x.id !== b.id))}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function ProductEdit() {
  const { books, setBooks, categories } = useApp()
  const { path, navigate } = useRouter()
  const id = path.split('/').pop()
  const existing = books.find((b) => b.id === id)
  const blank: Book = existing ?? {
    id: uid('bk'), slug: '', title: '', author: '', authorBio: '', description: '', longDescription: '',
    categoryId: categories[0]?.id ?? '', tags: [], isbn: '', publisher: '', language: 'English', pages: 200,
    format: 'Paperback', dimensions: '', publishedAt: new Date().toISOString().slice(0, 10),
    costPrice: 0, price: 0, salePrice: null, stock: 0, reserved: 0, lowStockAt: 5, sku: '',
    featured: false, bestseller: false, newArrival: true, published: true, rating: 0, reviewCount: 0,
    coverTone: '#243F35', views: 0, wishlistCount: 0, cartAdds: 0, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
  }
  const [form, setForm] = useState(blank)
  const set = <K extends keyof Book>(k: K, v: Book[K]) => setForm((f) => ({ ...f, [k]: v, slug: k === 'title' ? slugify(String(v)) : f.slug }))
  const save = () => {
    if (existing) setBooks(books.map((b) => (b.id === existing.id ? { ...form, updatedAt: new Date().toISOString() } : b)))
    else setBooks([{ ...form, slug: form.slug || slugify(form.title) }, ...books])
    navigate('/admin/products')
  }
  return (
    <>
      <h1>{existing ? 'Edit book' : 'New book'}</h1>
      <div className="space" />
      <div className="panel" style={{ display: 'grid', gap: 12 }}>
        <div className="field"><label>Title</label><input value={form.title} onChange={(e) => set('title', e.target.value)} /></div>
        <div className="field"><label>Author</label><input value={form.author} onChange={(e) => set('author', e.target.value)} /></div>
        <div className="field"><label>Description</label><textarea rows={3} value={form.description} onChange={(e) => set('description', e.target.value)} /></div>
        <div className="field"><label>Long description</label><textarea rows={4} value={form.longDescription} onChange={(e) => set('longDescription', e.target.value)} /></div>
        <div className="field"><label>Author bio</label><textarea rows={3} value={form.authorBio} onChange={(e) => set('authorBio', e.target.value)} /></div>
        <div className="row">
          <div className="field grow"><label>Cost</label><input type="number" value={form.costPrice} onChange={(e) => set('costPrice', Number(e.target.value))} /></div>
          <div className="field grow"><label>Price</label><input type="number" value={form.price} onChange={(e) => set('price', Number(e.target.value))} /></div>
          <div className="field grow"><label>Sale price</label><input type="number" value={form.salePrice ?? ''} onChange={(e) => set('salePrice', e.target.value ? Number(e.target.value) : null)} /></div>
        </div>
        <div className="row">
          <div className="field grow"><label>Stock</label><input type="number" value={form.stock} onChange={(e) => set('stock', Number(e.target.value))} /></div>
          <div className="field grow"><label>SKU</label><input value={form.sku} onChange={(e) => set('sku', e.target.value)} /></div>
          <div className="field grow"><label>ISBN</label><input value={form.isbn} onChange={(e) => set('isbn', e.target.value)} /></div>
        </div>
        <div className="row">
          <div className="field grow"><label>Publisher</label><input value={form.publisher} onChange={(e) => set('publisher', e.target.value)} /></div>
          <div className="field grow"><label>Pages</label><input type="number" value={form.pages} onChange={(e) => set('pages', Number(e.target.value))} /></div>
          <div className="field grow"><label>Language</label><input value={form.language} onChange={(e) => set('language', e.target.value)} /></div>
        </div>
        <div className="field"><label>Category</label>
          <select value={form.categoryId} onChange={(e) => set('categoryId', e.target.value)}>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div className="field"><label>Tags (comma)</label><input value={form.tags.join(', ')} onChange={(e) => set('tags', e.target.value.split(',').map((t) => t.trim()).filter(Boolean))} /></div>
        <div className="field"><label>Cover tone</label><input value={form.coverTone} onChange={(e) => set('coverTone', e.target.value)} /></div>
        <label className="row"><input type="checkbox" checked={form.featured} onChange={(e) => set('featured', e.target.checked)} /> Featured</label>
        <label className="row"><input type="checkbox" checked={form.bestseller} onChange={(e) => set('bestseller', e.target.checked)} /> Bestseller</label>
        <label className="row"><input type="checkbox" checked={form.newArrival} onChange={(e) => set('newArrival', e.target.checked)} /> New arrival</label>
        <label className="row"><input type="checkbox" checked={form.published} onChange={(e) => set('published', e.target.checked)} /> Published</label>
        <button className="btn" onClick={save}>Save book</button>
      </div>
    </>
  )
}

function Categories() {
  const { categories, setCategories } = useApp()
  const [name, setName] = useState('')
  return (
    <>
      <h1>Categories</h1>
      <form className="row" style={{ margin: '12px 0' }} onSubmit={(e) => { e.preventDefault(); setCategories([...categories, { id: uid('cat'), slug: slugify(name), name, description: '', imageTone: '#243F35', featured: false, hidden: false, sortOrder: categories.length + 1 }]); setName('') }}>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="New category" />
        <button className="btn">Add</button>
      </form>
      <table className="table">
        <thead><tr><th>Name</th><th>Featured</th><th>Hidden</th><th></th></tr></thead>
        <tbody>
          {categories.map((c) => (
            <tr key={c.id}>
              <td>{c.name}</td>
              <td><input type="checkbox" checked={c.featured} onChange={(e) => setCategories(categories.map((x) => x.id === c.id ? { ...x, featured: e.target.checked } : x))} /></td>
              <td><input type="checkbox" checked={c.hidden} onChange={(e) => setCategories(categories.map((x) => x.id === c.id ? { ...x, hidden: e.target.checked } : x))} /></td>
              <td><button className="btn ghost" onClick={() => setCategories(categories.filter((x) => x.id !== c.id))}>Delete</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function Inventory() {
  const { books, adjustStock, inventoryLog } = useApp()
  const [delta, setDelta] = useState<Record<string, number>>({})
  return (
    <>
      <h1>Inventory</h1>
      <table className="table">
        <thead><tr><th>Book</th><th>SKU</th><th>Stock</th><th>Reserved</th><th>Available</th><th>Threshold</th><th>Adjust</th></tr></thead>
        <tbody>
          {books.map((b) => (
            <tr key={b.id}>
              <td>{b.title}</td><td>{b.sku}</td><td>{b.stock}</td><td>{b.reserved}</td>
              <td>{b.stock - b.reserved}</td><td>{b.lowStockAt}</td>
              <td>
                <input type="number" style={{ width: 70 }} value={delta[b.id] ?? 0} onChange={(e) => setDelta({ ...delta, [b.id]: Number(e.target.value) })} />
                <button className="btn ghost" onClick={() => adjustStock(b.id, delta[b.id] ?? 0, 'Manual adjustment')}>Apply</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <h3 style={{ marginTop: 24 }}>History</h3>
      <table className="table">
        <thead><tr><th>When</th><th>Book</th><th>Delta</th><th>Note</th></tr></thead>
        <tbody>
          {inventoryLog.slice(0, 20).map((l) => (
            <tr key={l.id}><td>{formatDate(l.at)}</td><td>{books.find((b) => b.id === l.bookId)?.title}</td><td>{l.delta}</td><td>{l.note}</td></tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function Orders() {
  const { orders } = useApp()
  return (
    <>
      <h1>Orders</h1>
      <table className="table">
        <thead><tr><th>ID</th><th>Customer</th><th>Date</th><th>Items</th><th>Amount</th><th>Pay</th><th>Status</th></tr></thead>
        <tbody>
          {orders.map((o) => (
            <tr key={o.id}>
              <td><Link href={`/admin/orders/${o.id}`}>{o.orderNumber}</Link></td>
              <td>{o.customerName}</td>
              <td>{formatDate(o.createdAt)}</td>
              <td>{o.items.reduce((s, i) => s + i.qty, 0)}</td>
              <td>{formatMoney(o.total)}</td>
              <td>{o.paymentMethod} / {o.paymentStatus}</td>
              <td>{o.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function OrderEdit() {
  const { orders, setOrderStatus, markPayment } = useApp()
  const { path } = useRouter()
  const id = path.split('/').pop()
  const o = orders.find((x) => x.id === id)
  if (!o) return <p>Missing order.</p>
  const statuses: OrderStatus[] = ['pending', 'confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered', 'cancelled', 'returned', 'refunded']
  return (
    <>
      <h1>{o.orderNumber}</h1>
      <p>{o.customerName} · {o.email} · {o.phone}</p>
      <p>{o.address.line1}, {o.address.city} {o.address.pincode}</p>
      <div className="space" />
      {o.items.map((i) => <p key={i.bookId}>{i.qty} × {i.title} · {formatMoney(i.lineTotal)}</p>)}
      <p>Discount {formatMoney(o.discount)} · Shipping {formatMoney(o.shipping)} · Total {formatMoney(o.total)}</p>
      <p>Payment: {o.paymentMethod} · {o.paymentStatus}{o.upiRef ? ` · UTR ${o.upiRef}` : ''}</p>
      {o.paymentMethod === 'upi' && o.paymentStatus !== 'paid' && (
        <button className="btn" style={{ marginTop: 12 }} onClick={() => markPayment(o.id, 'paid')}>
          Confirm UPI received
        </button>
      )}
      <div className="field" style={{ maxWidth: 280, marginTop: 16 }}>
        <label>Status</label>
        <select value={o.status} onChange={(e) => setOrderStatus(o.id, e.target.value as OrderStatus)}>
          {statuses.map((s) => <option key={s} value={s}>{orderStatusLabel(s)}</option>)}
        </select>
      </div>
    </>
  )
}

function Customers() {
  const { customers, orders } = useApp()
  return (
    <>
      <h1>Customers</h1>
      <table className="table">
        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Spend</th></tr></thead>
        <tbody>
          {customers.map((c) => {
            const mine = orders.filter((o) => o.email === c.email)
            return (
              <tr key={c.email}>
                <td>{c.name}</td><td>{c.email}</td><td>{c.phone}</td>
                <td>{mine.length}</td>
                <td>{formatMoney(mine.reduce((s, o) => s + o.total, 0))}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </>
  )
}

function Offers() {
  const { coupons, setCoupons } = useApp()
  const [code, setCode] = useState('')
  return (
    <>
      <h1>Offers</h1>
      <form className="row" onSubmit={(e) => {
        e.preventDefault()
        const next: Coupon = {
          id: uid('cp'), code: code.toUpperCase(), type: 'percent', value: 10, minOrder: 0, maxDiscount: 200,
          startsAt: '2026-01-01', expiresAt: '2026-12-31', usageLimit: 100, perUserLimit: 1, usedCount: 0, active: true, description: '',
        }
        setCoupons([next, ...coupons]); setCode('')
      }}>
        <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="New code" />
        <button className="btn">Add 10% coupon</button>
      </form>
      <table className="table">
        <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Used</th><th>Active</th></tr></thead>
        <tbody>
          {coupons.map((c) => (
            <tr key={c.id}>
              <td>{c.code}</td><td>{c.type}</td><td>{c.value}</td><td>{c.usedCount}/{c.usageLimit}</td>
              <td><input type="checkbox" checked={c.active} onChange={(e) => setCoupons(coupons.map((x) => x.id === c.id ? { ...x, active: e.target.checked } : x))} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function ReviewsAdmin() {
  const { reviews, setReviews } = useApp()
  return (
    <>
      <h1>Reviews</h1>
      <table className="table">
        <thead><tr><th>Book</th><th>Customer</th><th>Rating</th><th>Body</th><th>Status</th></tr></thead>
        <tbody>
          {reviews.map((r) => (
            <tr key={r.id}>
              <td>{r.bookId}</td><td>{r.customerName}</td><td>{r.rating}</td><td>{r.body}</td>
              <td>
                <button className="btn ghost" onClick={() => setReviews(reviews.map((x) => x.id === r.id ? { ...x, status: 'approved' } : x))}>Approve</button>
                <button className="btn ghost" onClick={() => setReviews(reviews.map((x) => x.id === r.id ? { ...x, status: 'hidden' } : x))}>Hide</button>
                <button className="btn ghost" onClick={() => setReviews(reviews.filter((x) => x.id !== r.id))}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function Analytics() {
  const { orders, books, customers, events, coupons } = useApp()
  const [range, setRange] = useState('30')
  const from = Date.now() - Number(range) * 86400000
  const inRange = orders.filter((o) => +new Date(o.createdAt) >= from)
  const paid = inRange.filter((o) => o.paymentStatus === 'paid' || o.status === 'delivered')
  const refunded = inRange.filter((o) => o.status === 'refunded')
  const gross = paid.reduce((s, o) => s + o.subtotal, 0)
  const discounts = paid.reduce((s, o) => s + o.discount, 0)
  const net = paid.reduce((s, o) => s + o.total, 0) - refunded.reduce((s, o) => s + o.total, 0)
  const cost = paid.flatMap((o) => o.items.map((i) => {
    const book = books.find((b) => b.id === i.bookId)
    return book ? book.costPrice * i.qty : 0
  })).reduce((s, n) => s + n, 0)
  const profit = net - cost
  const units = paid.flatMap((o) => o.items).reduce((s, i) => s + i.qty, 0)
  const insights = [
    `${paid.length} completed/paid orders in the selected window.`,
    `${books.filter((b) => b.stock <= b.lowStockAt).length} titles are at or below their stock threshold.`,
    `Returning addresses in the full ledger: ${customers.length} unique customers.`,
    paid[0] ? `${paid[0].items[0]?.title ?? 'A title'} appears in a recent paid order.` : 'No paid orders in this window yet.',
  ]
  const exportCsv = () => {
    const rows = [['Order', 'Date', 'Customer', 'Total', 'Status'], ...inRange.map((o) => [o.orderNumber, o.createdAt, o.customerName, String(o.total), o.status])]
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'lumen-folio-orders.csv'
    a.click()
  }
  return (
    <>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Analytics</h1>
        <select value={range} onChange={(e) => setRange(e.target.value)}>
          <option value="1">Today</option>
          <option value="7">Last 7 days</option>
          <option value="30">Last 30 days</option>
          <option value="365">This year-ish</option>
        </select>
      </div>
      <p className="tiny">Figures below are computed from stored orders, inventory costs, and tracked events. They are not estimates unless labelled as such.</p>
      <div className="stat-grid" style={{ marginTop: 12 }}>
        <div className="stat">Gross merchandise<b>{formatMoney(gross)}</b></div>
        <div className="stat">After discounts / refunds<b>{formatMoney(net)}</b></div>
        <div className="stat">Discounts given<b>{formatMoney(discounts)}</b></div>
        <div className="stat">Gross profit (where cost exists)<b>{formatMoney(profit)}</b></div>
        <div className="stat">Orders in window<b>{inRange.length}</b></div>
        <div className="stat">Units sold<b>{units}</b></div>
        <div className="stat">AOV<b>{paid.length ? formatMoney(net / paid.length) : '—'}</b></div>
        <div className="stat">Tracked events<b>{events.length}</b></div>
      </div>
      <div className="space-lg" />
      <h3>Product movement</h3>
      <table className="table">
        <thead><tr><th>Title</th><th>Views</th><th>Cart adds</th><th>Wishlist</th><th>Stock</th><th>Margin</th></tr></thead>
        <tbody>
          {books.slice().sort((a, b) => b.views - a.views).slice(0, 12).map((b) => {
            const sell = effectivePrice(b.price, b.salePrice)
            const margin = b.costPrice ? Math.round(((sell - b.costPrice) / sell) * 100) : null
            return <tr key={b.id}><td>{b.title}</td><td>{b.views}</td><td>{b.cartAdds}</td><td>{b.wishlistCount}</td><td>{b.stock}</td><td>{margin == null ? '—' : `${margin}%`}</td></tr>
          })}
        </tbody>
      </table>
      <div className="space" />
      <h3>Coupons</h3>
      <table className="table">
        <thead><tr><th>Code</th><th>Uses</th></tr></thead>
        <tbody>{coupons.map((c) => <tr key={c.id}><td>{c.code}</td><td>{c.usedCount}</td></tr>)}</tbody>
      </table>
      <div className="space" />
      <h3>Insights</h3>
      {insights.map((i) => <p key={i} className="panel" style={{ marginBottom: 8 }}>{i}</p>)}
      <button className="btn" onClick={exportCsv}>Export orders CSV</button>
      <p className="tiny" style={{ marginTop: 8 }}>Visitor counts are not invented. Conversion rates appear only when view and purchase events exist.</p>
    </>
  )
}

function WebsiteEditor() {
  const { draftSite, setDraftSite, publishSite, versions, restoreVersion, site } = useApp()
  const d = draftSite
  const set = (patch: Partial<SiteSettings>) => setDraftSite({ ...d, ...patch })
  const setHero = (patch: Partial<SiteSettings['hero']>) => set({ hero: { ...d.hero, ...patch } })
  const [tab, setTab] = useState<'brand' | 'design' | 'home' | 'seo'>('home')
  return (
    <>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Website editor</h1>
        <div className="row">
          <span className="tiny">Draft</span>
          <button className="btn" onClick={publishSite}>Publish</button>
        </div>
      </div>
      <div className="chip-row" style={{ margin: '12px 0' }}>
        {(['home', 'brand', 'design', 'seo'] as const).map((t) => <button key={t} className={`chip ${tab === t ? 'on' : ''}`} onClick={() => setTab(t)}>{t}</button>)}
      </div>
      <div className="editor">
        <div className="editor-col">
          {Object.entries(d.sectionVisibility).map(([k, v]) => (
            <label key={k} className="row" style={{ padding: '6px 0' }}>
              <input type="checkbox" checked={v} onChange={(e) => set({ sectionVisibility: { ...d.sectionVisibility, [k]: e.target.checked } })} />
              {k}
            </label>
          ))}
        </div>
        <div className="editor-col">
          <div className="tiny">Live preview (draft values)</div>
          <h2>{d.hero.headline}</h2>
          <p className="muted">{d.hero.subheadline}</p>
          <div className="space" />
          <div className="btn">{d.hero.primaryCta}</div>
        </div>
        <div className="editor-col">
          {tab === 'home' && (
            <>
              <div className="field"><label>Headline</label><input value={d.hero.headline} onChange={(e) => setHero({ headline: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>Subheadline</label><textarea value={d.hero.subheadline} onChange={(e) => setHero({ subheadline: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>Primary button</label><input value={d.hero.primaryCta} onChange={(e) => setHero({ primaryCta: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>Announcement</label><input value={d.announcement.text} onChange={(e) => set({ announcement: { ...d.announcement, text: e.target.value } })} /></div>
            </>
          )}
          {tab === 'brand' && (
            <>
              <div className="field"><label>Store name</label><input value={d.storeName} onChange={(e) => set({ storeName: e.target.value, logoText: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>Tagline</label><input value={d.tagline} onChange={(e) => set({ tagline: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>Phone</label><input value={d.phone} onChange={(e) => set({ phone: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>Email</label><input value={d.email} onChange={(e) => set({ email: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>WhatsApp</label><input value={d.whatsapp} onChange={(e) => set({ whatsapp: e.target.value })} /></div>
              <div className="space" />
              <div className="field"><label>Footer</label><textarea value={d.footerText} onChange={(e) => set({ footerText: e.target.value })} /></div>
            </>
          )}
          {tab === 'design' && (
            <>
              {Object.entries(d.colors).map(([k, v]) => (
                <div key={k} className="field" style={{ marginBottom: 8 }}>
                  <label>{k}</label>
                  <input value={v} onChange={(e) => set({ colors: { ...d.colors, [k]: e.target.value } })} />
                </div>
              ))}
            </>
          )}
          {tab === 'seo' && (
            <>
              <div className="field"><label>SEO title</label><input value={d.seo.title} onChange={(e) => set({ seo: { ...d.seo, title: e.target.value } })} /></div>
              <div className="space" />
              <div className="field"><label>Meta description</label><textarea value={d.seo.description} onChange={(e) => set({ seo: { ...d.seo, description: e.target.value } })} /></div>
            </>
          )}
        </div>
      </div>
      <h3 style={{ marginTop: 20 }}>Versions</h3>
      {!versions.length && <p className="muted">Publish to start history. Live store currently uses settings saved {site.storeName}.</p>}
      {versions.map((v) => (
        <div key={v.at} className="row" style={{ marginTop: 6 }}>
          <span>{v.at}</span>
          <button className="btn ghost" onClick={() => restoreVersion(v.at)}>Restore to draft</button>
        </div>
      ))}
    </>
  )
}

function Media() {
  const [files, setFiles] = useState<{ name: string; url: string }[]>([])
  return (
    <>
      <h1>Media library</h1>
      <p className="muted">In production this writes to Supabase Storage. Here, files stay in the browser session for reuse on covers and pages.</p>
      <input type="file" accept="image/*" multiple onChange={(e) => {
        const list = [...(e.target.files ?? [])].map((f) => ({ name: f.name, url: URL.createObjectURL(f) }))
        setFiles((prev) => [...list, ...prev])
      }} />
      <div className="book-grid" style={{ marginTop: 16 }}>
        {files.map((f) => (
          <figure key={f.url} className="panel">
            <img src={f.url} alt={f.name} style={{ width: '100%', aspectRatio: '1', objectFit: 'cover' }} />
            <figcaption className="tiny">{f.name}</figcaption>
          </figure>
        ))}
      </div>
    </>
  )
}

function Settings() {
  const { draftSite, setDraftSite, publishSite } = useApp()
  return (
    <>
      <h1>Store settings</h1>
      <div className="panel" style={{ display: 'grid', gap: 12, maxWidth: 560 }}>
        <div className="field"><label>Copyright</label><input value={draftSite.copyright} onChange={(e) => setDraftSite({ ...draftSite, copyright: e.target.value })} /></div>
        <div className="field"><label>Address</label><input value={draftSite.address} onChange={(e) => setDraftSite({ ...draftSite, address: e.target.value })} /></div>
        <div className="field"><label>UPI ID</label><input value={draftSite.upiId} onChange={(e) => setDraftSite({ ...draftSite, upiId: e.target.value.trim() })} /></div>
        <div className="field"><label>UPI display name</label><input value={draftSite.upiName} onChange={(e) => setDraftSite({ ...draftSite, upiName: e.target.value })} /></div>
        <button className="btn" onClick={publishSite}>Save & publish</button>
      </div>
    </>
  )
}

function Security() {
  const { ownerLogout, changeOwnerPassword } = useApp()
  const { navigate } = useRouter()
  const [next, setNext] = useState('')
  return (
    <>
      <h1>Security</h1>
      <p className="muted">Production password changes go through Supabase Auth. Never store a plaintext password in Postgres.</p>
      <div className="field" style={{ maxWidth: 360 }}>
        <label>New owner password</label>
        <input type="password" value={next} onChange={(e) => setNext(e.target.value)} />
      </div>
      <div className="space" />
      <button className="btn" onClick={() => changeOwnerPassword(next)}>Update password</button>
      <div className="space" />
      <button className="btn ghost" onClick={() => { ownerLogout(); navigate('/admin/login') }}>Log out</button>
    </>
  )
}
