/**
 * Production client. The demo store runs without these keys.
 * Never import a service-role key from this module.
 */
export function getSupabaseConfig() {
  const url = import.meta.env.VITE_SUPABASE_URL
  const anon = import.meta.env.VITE_SUPABASE_ANON_KEY
  if (!url || !anon) return null
  return { url, anon }
}
