import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

type RouterCtx = {
  path: string
  query: URLSearchParams
  navigate: (to: string, replace?: boolean) => void
}

const Ctx = createContext<RouterCtx | null>(null)

function readLocation() {
  return { path: window.location.pathname, query: new URLSearchParams(window.location.search) }
}

export function Router({ children }: { children: ReactNode }) {
  const [loc, setLoc] = useState(readLocation)
  useEffect(() => {
    const onPop = () => setLoc(readLocation())
    window.addEventListener('popstate', onPop)
    return () => window.removeEventListener('popstate', onPop)
  }, [])
  const navigate = (to: string, replace = false) => {
    if (replace) window.history.replaceState({}, '', to)
    else window.history.pushState({}, '', to)
    setLoc(readLocation())
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior })
  }
  return <Ctx.Provider value={{ ...loc, navigate }}>{children}</Ctx.Provider>
}

export function useRouter() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('router')
  return ctx
}

export function Link({
  href,
  className,
  children,
}: {
  href: string
  className?: string
  children: ReactNode
}) {
  const { path, navigate } = useRouter()
  const clean = href.split('?')[0]
  const active = path === clean || (clean !== '/' && path.startsWith(clean + '/'))
  return (
    <a
      href={href}
      className={`${className ?? ''} ${active ? 'active' : ''}`.trim()}
      onClick={(e) => {
        if (e.metaKey || e.ctrlKey || e.button !== 0) return
        e.preventDefault()
        navigate(href)
      }}
    >
      {children}
    </a>
  )
}

export function match(path: string, pattern: string) {
  const pp = pattern.split('/').filter(Boolean)
  const segs = path.split('/').filter(Boolean)
  if (pattern.endsWith('*')) {
    const base = pattern.slice(0, -1)
    return path.startsWith(base) ? {} : null
  }
  if (pp.length !== segs.length) return null
  const params: Record<string, string> = {}
  for (let i = 0; i < pp.length; i++) {
    if (pp[i].startsWith(':')) params[pp[i].slice(1)] = decodeURIComponent(segs[i])
    else if (pp[i] !== segs[i]) return null
  }
  return params
}
