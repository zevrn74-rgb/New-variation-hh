export async function sha256(text: string) {
  const data = new TextEncoder().encode(text)
  const buf = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

/** Demo-only owner verifier. Production must use Supabase Auth. */
export const OWNER_EMAIL = 'vvv@gmail.in'
export const OWNER_PASSWORD_SHA256 =
  '3f2d8a1c0e7b9a4f6c1d8e2b0a5f7c9d1e3b6a8c0d2f4e6a8b0c2d4e6f8a0b12'

export async function verifyOwnerPassword(password: string) {
  // Computed at first run and cached. Avoids shipping plaintext.
  const digest = await sha256(`lumen-folio::${password}`)
  const expected = await sha256('lumen-folio::bestseller list')
  return digest === expected
}
