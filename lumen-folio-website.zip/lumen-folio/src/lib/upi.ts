export function upiPayUrl(opts: { pa: string; pn: string; amount: number; note: string }) {
  const params = new URLSearchParams({
    pa: opts.pa,
    pn: opts.pn,
    am: String(opts.amount),
    cu: 'INR',
    tn: opts.note,
  })
  return `upi://pay?${params.toString()}`
}
