import type { Book, CartItem, Coupon } from '../types'
import { effectivePrice } from './format'

export function shippingFor(subtotal: number, free: boolean) {
  if (free || subtotal >= 799) return 0
  return 59
}

export function applyCoupon(
  coupon: Coupon | null,
  items: { book: Book; qty: number }[],
  subtotal: number,
) {
  if (!coupon || !coupon.active) return { discount: 0, freeShipping: false, error: null as string | null }
  const today = new Date().toISOString().slice(0, 10)
  if (today < coupon.startsAt) return { discount: 0, freeShipping: false, error: 'This code is not active yet.' }
  if (today > coupon.expiresAt) return { discount: 0, freeShipping: false, error: 'This code has expired.' }
  if (coupon.usedCount >= coupon.usageLimit) return { discount: 0, freeShipping: false, error: 'This code has reached its limit.' }
  if (subtotal < coupon.minOrder) {
    return { discount: 0, freeShipping: false, error: `Add items worth ₹${coupon.minOrder} to use this code.` }
  }

  if (coupon.type === 'free_shipping') return { discount: 0, freeShipping: true, error: null }
  if (coupon.type === 'percent') {
    const raw = Math.round((subtotal * coupon.value) / 100)
    const discount = coupon.maxDiscount ? Math.min(raw, coupon.maxDiscount) : raw
    return { discount, freeShipping: false, error: null }
  }
  if (coupon.type === 'fixed') {
    return { discount: Math.min(coupon.value, subtotal), freeShipping: false, error: null }
  }
  if (coupon.type === 'b2g1' || coupon.type === 'bxgy') {
    const units = items.flatMap((line) =>
      Array.from({ length: line.qty }, () => effectivePrice(line.book.price, line.book.salePrice)),
    )
    if (units.length < 3 && coupon.type === 'b2g1') {
      return { discount: 0, freeShipping: false, error: 'Add at least three books for Buy 2 Get 1.' }
    }
    units.sort((a, b) => a - b)
    const freeCount = coupon.type === 'b2g1' ? Math.floor(units.length / 3) : coupon.getQty ?? 1
    const discount = units.slice(0, freeCount).reduce((s, n) => s + n, 0)
    return { discount, freeShipping: false, error: null }
  }
  if (coupon.type === 'category' && coupon.categoryId) {
    const catSub = items
      .filter((l) => l.book.categoryId === coupon.categoryId)
      .reduce((s, l) => s + effectivePrice(l.book.price, l.book.salePrice) * l.qty, 0)
    const raw = Math.round((catSub * coupon.value) / 100)
    return { discount: raw, freeShipping: false, error: null }
  }
  if (coupon.type === 'product' && coupon.productId) {
    const line = items.find((l) => l.book.id === coupon.productId)
    if (!line) return { discount: 0, freeShipping: false, error: 'This code applies to a title not in your cart.' }
    const raw = Math.round((effectivePrice(line.book.price, line.book.salePrice) * line.qty * coupon.value) / 100)
    return { discount: raw, freeShipping: false, error: null }
  }
  return { discount: 0, freeShipping: false, error: null }
}

export function cartLines(items: CartItem[], books: Book[]) {
  return items
    .filter((i) => !i.savedForLater)
    .map((i) => {
      const book = books.find((b) => b.id === i.bookId)
      return book ? { book, qty: i.qty } : null
    })
    .filter((x): x is { book: Book; qty: number } => Boolean(x))
}
