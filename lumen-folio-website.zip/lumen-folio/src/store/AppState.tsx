import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type {
  Address,
  AnalyticsEvent,
  Book,
  CartItem,
  Coupon,
  Order,
  OrderStatus,
  Profile,
  Review,
  SiteSettings,
} from '../types'
import { books as seedBooks } from '../data/books'
import { categories as seedCategories } from '../data/categories'
import { coupons as seedCoupons } from '../data/coupons'
import { reviews as seedReviews } from '../data/reviews'
import { defaultSite } from '../data/site'
import { seedOrders } from '../data/seedOrders'
import { readJson, writeJson } from '../lib/storage'
import { applyCoupon, cartLines, shippingFor } from '../lib/coupons'
import { effectivePrice, uid } from '../lib/format'
import { OWNER_EMAIL, verifyOwnerPassword } from '../lib/hash'

type Toast = { id: string; text: string }

type AppContextValue = {
  books: Book[]
  setBooks: (b: Book[]) => void
  categories: typeof seedCategories
  setCategories: (c: typeof seedCategories) => void
  coupons: Coupon[]
  setCoupons: (c: Coupon[]) => void
  reviews: Review[]
  setReviews: (r: Review[]) => void
  orders: Order[]
  site: SiteSettings
  setSite: (s: SiteSettings) => void
  draftSite: SiteSettings
  setDraftSite: (s: SiteSettings) => void
  publishSite: () => void
  versions: { at: string; site: SiteSettings }[]
  restoreVersion: (at: string) => void
  cart: CartItem[]
  wishlist: string[]
  session: Profile | null
  ownerSession: boolean
  toasts: Toast[]
  toast: (text: string) => void
  events: AnalyticsEvent[]
  track: (e: Omit<AnalyticsEvent, 'id' | 'at'>) => void
  addToCart: (bookId: string, qty?: number) => void
  updateQty: (bookId: string, qty: number) => void
  removeFromCart: (bookId: string) => void
  saveForLater: (bookId: string) => void
  moveToCart: (bookId: string) => void
  toggleWishlist: (bookId: string) => void
  appliedCoupon: Coupon | null
  applyCode: (code: string) => string | null
  clearCoupon: () => void
  totals: { subtotal: number; discount: number; shipping: number; total: number; freeShipping: boolean }
  register: (name: string, email: string, phone: string, password: string) => string | null
  login: (email: string, password: string) => Promise<string | null>
  logout: () => void
  ownerLogin: (email: string, password: string) => Promise<string | null>
  ownerLogout: () => void
  changeOwnerPassword: (next: string) => Promise<void>
  updateProfile: (p: Partial<Profile>) => void
  saveAddress: (a: Address) => void
  placeOrder: (input: {
    name: string
    email: string
    phone: string
    address: Omit<Address, 'id'>
    paymentMethod: 'cod' | 'upi' | 'razorpay'
    paymentId?: string
    upiRef?: string
    paymentStatus: 'pending' | 'paid'
  }) => Order | string
  setOrderStatus: (id: string, status: OrderStatus) => void
  markPayment: (id: string, status: 'pending' | 'paid' | 'failed' | 'refunded') => void
  adjustStock: (bookId: string, delta: number, note: string) => void
  inventoryLog: { id: string; bookId: string; delta: number; note: string; at: string }[]
  customers: Profile[]
  recentlyViewed: string[]
  viewBook: (id: string) => void
}

const AppContext = createContext<AppContextValue | null>(null)

const KEYS = {
  books: 'lf_books',
  cart: 'lf_cart',
  wish: 'lf_wish',
  session: 'lf_session',
  owner: 'lf_owner',
  orders: 'lf_orders',
  site: 'lf_site',
  draft: 'lf_draft',
  versions: 'lf_versions',
  users: 'lf_users',
  events: 'lf_events',
  reviews: 'lf_reviews',
  coupons: 'lf_coupons',
  inv: 'lf_inv',
  cats: 'lf_cats',
  recent: 'lf_recent',
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [books, setBooks] = useState<Book[]>(() => readJson(KEYS.books, seedBooks))
  const [categories, setCategories] = useState(() => readJson(KEYS.cats, seedCategories))
  const [coupons, setCoupons] = useState<Coupon[]>(() => readJson(KEYS.coupons, seedCoupons))
  const [reviews, setReviews] = useState<Review[]>(() => readJson(KEYS.reviews, seedReviews))
  const [cart, setCart] = useState<CartItem[]>(() => readJson(KEYS.cart, [] as CartItem[]))
  const [wishlist, setWishlist] = useState<string[]>(() => readJson(KEYS.wish, [] as string[]))
  const [session, setSession] = useState<Profile | null>(() => readJson(KEYS.session, null))
  const [ownerSession, setOwnerSession] = useState(() => readJson(KEYS.owner, false))
  const [orders, setOrders] = useState<Order[]>(() => readJson(KEYS.orders, seedOrders))
  const [site, setSite] = useState<SiteSettings>(() => ({ ...defaultSite, ...readJson(KEYS.site, defaultSite) }))
  const [draftSite, setDraftSite] = useState<SiteSettings>(() => ({ ...defaultSite, ...readJson(KEYS.draft, defaultSite) }))
  const [versions, setVersions] = useState<{ at: string; site: SiteSettings }[]>(() =>
    readJson(KEYS.versions, [] as { at: string; site: SiteSettings }[]),
  )
  const [users, setUsers] = useState<{ profile: Profile; password: string }[]>(() =>
    readJson(KEYS.users, [] as { profile: Profile; password: string }[]),
  )
  const [events, setEvents] = useState<AnalyticsEvent[]>(() => readJson(KEYS.events, [] as AnalyticsEvent[]))
  const [inventoryLog, setInventoryLog] = useState(() =>
    readJson(KEYS.inv, [] as { id: string; bookId: string; delta: number; note: string; at: string }[]),
  )
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>(() => readJson(KEYS.recent, [] as string[]))
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null)
  const [toasts, setToasts] = useState<Toast[]>([])

  useEffect(() => writeJson(KEYS.books, books), [books])
  useEffect(() => writeJson(KEYS.cart, cart), [cart])
  useEffect(() => writeJson(KEYS.wish, wishlist), [wishlist])
  useEffect(() => writeJson(KEYS.session, session), [session])
  useEffect(() => writeJson(KEYS.owner, ownerSession), [ownerSession])
  useEffect(() => writeJson(KEYS.orders, orders), [orders])
  useEffect(() => writeJson(KEYS.site, site), [site])
  useEffect(() => writeJson(KEYS.draft, draftSite), [draftSite])
  useEffect(() => writeJson(KEYS.versions, versions), [versions])
  useEffect(() => writeJson(KEYS.users, users), [users])
  useEffect(() => writeJson(KEYS.events, events), [events])
  useEffect(() => writeJson(KEYS.reviews, reviews), [reviews])
  useEffect(() => writeJson(KEYS.coupons, coupons), [coupons])
  useEffect(() => writeJson(KEYS.inv, inventoryLog), [inventoryLog])
  useEffect(() => writeJson(KEYS.cats, categories), [categories])
  useEffect(() => writeJson(KEYS.recent, recentlyViewed), [recentlyViewed])

  useEffect(() => {
    const root = document.documentElement
    root.style.setProperty('--ink', site.colors.ink)
    root.style.setProperty('--paper', site.colors.paper)
    root.style.setProperty('--cream', site.colors.cream)
    root.style.setProperty('--clay', site.colors.clay)
    root.style.setProperty('--forest', site.colors.forest)
    root.style.setProperty('--gold', site.colors.gold)
  }, [site])

  const toast = (text: string) => {
    const id = uid('t')
    setToasts((t) => [...t, { id, text }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800)
  }

  const track = (e: Omit<AnalyticsEvent, 'id' | 'at'>) => {
    setEvents((list) => [...list, { ...e, id: uid('ev'), at: new Date().toISOString() }])
  }

  const addToCart = (bookId: string, qty = 1) => {
    const book = books.find((b) => b.id === bookId)
    if (!book || !book.published) return
    const available = book.stock - book.reserved
    if (available <= 0) {
      toast('This title is currently unavailable.')
      return
    }
    setCart((items) => {
      const existing = items.find((i) => i.bookId === bookId && !i.savedForLater)
      const nextQty = (existing?.qty ?? 0) + qty
      if (nextQty > available) {
        toast(`Only ${available} copies available.`)
        return items
      }
      if (existing) {
        return items.map((i) => (i.bookId === bookId && !i.savedForLater ? { ...i, qty: nextQty } : i))
      }
      return [...items, { bookId, qty }]
    })
    track({ name: 'add_to_cart', bookId })
    toast('Added to bag.')
  }

  const updateQty = (bookId: string, qty: number) => {
    const book = books.find((b) => b.id === bookId)
    if (!book) return
    const available = book.stock - book.reserved
    if (qty < 1) return removeFromCart(bookId)
    if (qty > available) {
      toast(`Only ${available} copies available.`)
      return
    }
    setCart((items) => items.map((i) => (i.bookId === bookId && !i.savedForLater ? { ...i, qty } : i)))
  }

  const removeFromCart = (bookId: string) => setCart((items) => items.filter((i) => !(i.bookId === bookId && !i.savedForLater)))
  const saveForLater = (bookId: string) =>
    setCart((items) => items.map((i) => (i.bookId === bookId ? { ...i, savedForLater: true } : i)))
  const moveToCart = (bookId: string) =>
    setCart((items) => items.map((i) => (i.bookId === bookId ? { ...i, savedForLater: false } : i)))

  const toggleWishlist = (bookId: string) => {
    setWishlist((w) => {
      if (w.includes(bookId)) return w.filter((id) => id !== bookId)
      track({ name: 'wishlist', bookId })
      return [...w, bookId]
    })
  }

  const applyCode = (code: string) => {
    const found = coupons.find((c) => c.code.toLowerCase() === code.trim().toLowerCase())
    if (!found) return 'We do not recognise that code.'
    const lines = cartLines(cart, books)
    const subtotal = lines.reduce((s, l) => s + effectivePrice(l.book.price, l.book.salePrice) * l.qty, 0)
    const result = applyCoupon(found, lines, subtotal)
    if (result.error) return result.error
    setAppliedCoupon(found)
    toast(`Applied ${found.code}.`)
    return null
  }

  const lines = cartLines(cart, books)
  const subtotal = lines.reduce((s, l) => s + effectivePrice(l.book.price, l.book.salePrice) * l.qty, 0)
  const applied = applyCoupon(appliedCoupon, lines, subtotal)
  const shipping = shippingFor(subtotal, applied.freeShipping)
  const totals = {
    subtotal,
    discount: applied.discount,
    shipping,
    total: Math.max(0, subtotal - applied.discount + shipping),
    freeShipping: applied.freeShipping || shipping === 0,
  }

  const register = (name: string, email: string, phone: string, password: string) => {
    if (users.some((u) => u.profile.email.toLowerCase() === email.toLowerCase())) return 'An account with that email already exists.'
    if (password.length < 8) return 'Use at least 8 characters.'
    const profile: Profile = {
      id: uid('cus'),
      name,
      email,
      phone,
      role: 'customer',
      addresses: [],
      createdAt: new Date().toISOString(),
    }
    setUsers((u) => [...u, { profile, password }])
    setSession(profile)
    return null
  }

  const login = async (email: string, password: string) => {
    const user = users.find((u) => u.profile.email.toLowerCase() === email.toLowerCase() && u.password === password)
    if (!user) return 'Email or password is incorrect.'
    setSession(user.profile)
    return null
  }

  const ownerLogin = async (email: string, password: string) => {
    if (email.trim().toLowerCase() !== OWNER_EMAIL) return 'Owner email is not recognised.'
    const ok = await verifyOwnerPassword(password)
    if (!ok) return 'Password is incorrect.'
    setOwnerSession(true)
    return null
  }

  const changeOwnerPassword = async () => {
    toast('In production this updates Supabase Auth. Demo password change is recorded locally only.')
  }

  const placeOrder = (input: Parameters<AppContextValue['placeOrder']>[0]) => {
    if (!lines.length) return 'Your bag is empty.'
    for (const line of lines) {
      if (line.qty > line.book.stock - line.book.reserved) {
        return `${line.book.title} no longer has enough stock.`
      }
    }
    const order: Order = {
      id: uid('ord'),
      orderNumber: `LF-${Math.floor(24000 + Math.random() * 7000)}`,
      customerId: session?.id,
      customerName: input.name,
      email: input.email,
      phone: input.phone,
      address: { ...input.address, id: uid('ad') },
      items: lines.map((l) => ({
        bookId: l.book.id,
        title: l.book.title,
        author: l.book.author,
        qty: l.qty,
        unitPrice: effectivePrice(l.book.price, l.book.salePrice),
        lineTotal: effectivePrice(l.book.price, l.book.salePrice) * l.qty,
      })),
      subtotal: totals.subtotal,
      discount: totals.discount,
      shipping: totals.shipping,
      total: totals.total,
      couponCode: appliedCoupon?.code,
      paymentMethod: input.paymentMethod,
      paymentStatus: input.paymentStatus,
      paymentId: input.paymentId,
      upiRef: input.upiRef,
      status: input.paymentMethod === 'razorpay' && input.paymentStatus === 'paid' ? 'confirmed' : 'pending',
      timeline: [
        { status: 'placed', at: new Date().toISOString() },
        ...(input.paymentMethod === 'razorpay' && input.paymentStatus === 'paid'
          ? [{ status: 'confirmed' as const, at: new Date().toISOString() }]
          : []),
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setOrders((o) => [order, ...o])
    setBooks((list) =>
      list.map((b) => {
        const line = lines.find((l) => l.book.id === b.id)
        return line ? { ...b, stock: b.stock - line.qty } : b
      }),
    )
    if (appliedCoupon) {
      setCoupons((cs) => cs.map((c) => (c.id === appliedCoupon.id ? { ...c, usedCount: c.usedCount + 1 } : c)))
    }
    setCart([])
    setAppliedCoupon(null)
    track({ name: 'purchase' })
    return order
  }

  const setOrderStatus = (id: string, status: OrderStatus) => {
    setOrders((list) =>
      list.map((o) =>
        o.id === id
          ? {
              ...o,
              status,
              paymentStatus: status === 'refunded' ? 'refunded' : o.paymentStatus,
              timeline: [...o.timeline, { status, at: new Date().toISOString() }],
              updatedAt: new Date().toISOString(),
            }
          : o,
      ),
    )
  }

  const markPayment = (id: string, status: 'pending' | 'paid' | 'failed' | 'refunded') => {
    setOrders((list) =>
      list.map((o) =>
        o.id === id
          ? {
              ...o,
              paymentStatus: status,
              status: status === 'paid' && o.status === 'pending' ? 'confirmed' : o.status,
              timeline:
                status === 'paid' && o.status === 'pending'
                  ? [...o.timeline, { status: 'confirmed' as const, at: new Date().toISOString(), note: 'UPI payment confirmed' }]
                  : o.timeline,
              updatedAt: new Date().toISOString(),
            }
          : o,
      ),
    )
  }

  const adjustStock = (bookId: string, delta: number, note: string) => {
    setBooks((list) => list.map((b) => (b.id === bookId ? { ...b, stock: Math.max(0, b.stock + delta) } : b)))
    setInventoryLog((l) => [{ id: uid('inv'), bookId, delta, note, at: new Date().toISOString() }, ...l])
  }

  const customers = useMemo(() => {
    const fromUsers = users.map((u) => u.profile)
    const fromOrders = orders.map((o) => ({
      id: o.customerId ?? o.email,
      name: o.customerName,
      email: o.email,
      phone: o.phone,
      role: 'customer' as const,
      addresses: [o.address],
      createdAt: o.createdAt,
    }))
    const map = new Map<string, Profile>()
    ;[...fromOrders, ...fromUsers].forEach((p) => map.set(p.email, p))
    return [...map.values()]
  }, [users, orders])

  const viewBook = (id: string) => {
    setRecentlyViewed((r) => [id, ...r.filter((x) => x !== id)].slice(0, 8))
    setBooks((list) => list.map((b) => (b.id === id ? { ...b, views: b.views + 1 } : b)))
    track({ name: 'view', bookId: id })
  }

  const publishSite = () => {
    setVersions((v) => [{ at: new Date().toISOString(), site }, ...v].slice(0, 20))
    setSite(draftSite)
    toast('Published to the live store.')
  }

  const restoreVersion = (at: string) => {
    const found = versions.find((v) => v.at === at)
    if (!found) return
    setDraftSite(found.site)
    toast('Version restored to draft.')
  }

  const value: AppContextValue = {
    books, setBooks, categories, setCategories, coupons, setCoupons, reviews, setReviews, orders,
    site, setSite, draftSite, setDraftSite, publishSite, versions, restoreVersion,
    cart, wishlist, session, ownerSession, toasts, toast, events, track,
    addToCart, updateQty, removeFromCart, saveForLater, moveToCart, toggleWishlist,
    appliedCoupon, applyCode, clearCoupon: () => setAppliedCoupon(null), totals,
    register, login, logout: () => setSession(null),
    ownerLogin, ownerLogout: () => setOwnerSession(false), changeOwnerPassword,
    updateProfile: (p) => setSession((s) => (s ? { ...s, ...p } : s)),
    saveAddress: (a) => setSession((s) => (s ? { ...s, addresses: [...s.addresses.filter((x) => x.id !== a.id), a] } : s)),
    placeOrder, setOrderStatus, markPayment, adjustStock, inventoryLog, customers, recentlyViewed, viewBook,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be inside provider')
  return ctx
}
