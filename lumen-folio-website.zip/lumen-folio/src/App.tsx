import { AdminApp } from './pages/admin/AdminApp'
import { AccountPage, LoginPage } from './pages/store/AccountPages'
import { BookPage } from './pages/store/BookPage'
import { CartPage, CheckoutPage, OrderView, TrackPage, WishlistPage } from './pages/store/CartPages'
import { HomePage } from './pages/store/HomePage'
import { InfoPage } from './pages/store/InfoPages'
import { ShopPage } from './pages/store/ShopPage'
import { StoreShell } from './components/store/StoreShell'
import { match, useRouter } from './lib/router'
import { useApp } from './store/AppState'
import { useEffect, type ReactNode } from 'react'

function Seo() {
  const { site, books } = useApp()
  const { path } = useRouter()
  useEffect(() => {
    const book = match(path, '/book/:slug')
    const found = book ? books.find((b) => b.slug === book.slug) : null
    document.title = found ? `${found.title} — ${site.storeName}` : site.seo.title
    const desc = document.querySelector('meta[name="description"]')
    if (desc) desc.setAttribute('content', found ? found.description : site.seo.description)
  }, [path, site, books])
  return null
}

export default function App() {
  const { path } = useRouter()

  if (path.startsWith('/admin')) {
    return (
      <>
        <Seo />
        <AdminApp />
      </>
    )
  }

  const book = match(path, '/book/:slug')
  const order = match(path, '/order/:id')

  let page: ReactNode = <HomePage />
  if (path === '/shop') page = <ShopPage />
  else if (path === '/new') page = <ShopPage mode="new" />
  else if (path === '/bestsellers') page = <ShopPage mode="best" />
  else if (path === '/deals') page = <ShopPage mode="deals" />
  else if (path === '/categories') page = <ShopPage mode="cats" />
  else if (path === '/search') page = <ShopPage mode="search" />
  else if (book) page = <BookPage slug={book.slug} />
  else if (path === '/cart') page = <CartPage />
  else if (path === '/checkout') page = <CheckoutPage />
  else if (path === '/wishlist') page = <WishlistPage />
  else if (path === '/login') page = <LoginPage mode="login" />
  else if (path === '/register') page = <LoginPage mode="register" />
  else if (path === '/forgot-password') page = <LoginPage mode="forgot" />
  else if (path === '/account' || path === '/account/orders') page = <AccountPage />
  else if (path === '/track-order') page = <TrackPage />
  else if (order) page = <OrderView orderId={order.id} />
  else if (path === '/about') page = <InfoPage keyName="about" />
  else if (path === '/contact') page = <InfoPage keyName="contact" />
  else if (path === '/shipping') page = <InfoPage keyName="shipping" />
  else if (path === '/returns') page = <InfoPage keyName="returns" />
  else if (path === '/faq') page = <InfoPage keyName="faq" />
  else if (path === '/privacy') page = <InfoPage keyName="privacy" />
  else if (path === '/terms') page = <InfoPage keyName="terms" />
  else if (path !== '/') page = <div className="container empty">That page is not on the shelf.</div>

  return (
    <>
      <Seo />
      <StoreShell>{page}</StoreShell>
    </>
  )
}
