# Lumen Folio

Independent bookstore platform: customer storefront, installable PWA, owner control center, inventory, orders, coupons, reviews, analytics, and a draft/publish website editor.

Brand: **Lumen Folio** — Church Street, Bengaluru. Books bought at trade price and sold one copy at a time.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:5173

### Owner login (initial credentials)

- Email: `vvv@gmail.in`
- Password: `bestseller list`

The password is not stored in the client as plaintext. Demo mode hashes the attempt with Web Crypto. Production must create this user in Supabase Auth and set `profiles.role = 'owner'`. Change the password from `/admin/settings/security` once Auth is connected.

## What works in this build

- Full customer catalogue, filters, product pages, cart, wishlist, COD checkout
- Online checkout that refuses to create an order unless Razorpay payment is verified server-side
- Customer accounts, order tracking timeline
- Owner admin: products, inventory adjustments, orders, customers, coupons, reviews, analytics, media, website editor with draft/publish/versions
- PWA manifest and offline shell (checkout is not available offline)
- SQL schema + RLS in `supabase/schema.sql`

## Environment

Copy `.env.example` to `.env.local`.

Never commit or prefix with `VITE_`:

- Supabase service-role key
- Razorpay secret
- Database password

## Coupons in the demo catalogue

- FOLIO10 — 10% off above ₹799
- STUDENT15 — 15% off above ₹999
- FREESHIP — free shipping above ₹499
- TRIO — buy 2 get 1
- INK200 — ₹200 off above ₹1,499

## Deploy

1. Create a Supabase project and run `supabase/schema.sql`.
2. Create the owner Auth user. Set `profiles.role = 'owner'`.
3. Add Razorpay key id to `VITE_RAZORPAY_KEY_ID`.
4. Deploy `supabase/functions/verify-payment` with `RAZORPAY_KEY_SECRET`.
5. Import to Vercel with the env vars from `.env.example`.
